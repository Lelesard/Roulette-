"""Conservative OCR proposals, never derived from browser traffic."""

import shutil
import subprocess
import tempfile
import csv
import io
import os
from pathlib import Path

import cv2
from PySide6.QtCore import QObject, Signal, Slot


def reconcile(previous, current, min_overlap=3):
    """Newest-first lists. Return new prefix, or None if overlap is ambiguous.

    Identical snapshots do not create results. Repeated identical outcomes cannot
    be resolved from a static panel alone and are deliberately not inferred.
    """
    if len(current) < min_overlap:
        return None
    if not previous:
        return list(current)
    overlap = min(len(current), len(previous))
    if current[:overlap] == previous[:overlap] and overlap >= min_overlap:
        return []
    matches = []
    for added in range(1, len(current) - min_overlap + 1):
        length = min(len(previous), len(current) - added)
        if (
            length >= min_overlap
            and current[added : added + length] == previous[:length]
        ):
            matches.append(current[:added])
    return matches[0] if len(matches) == 1 else None


def _lcs_length(left, right):
    previous = [0] * (len(right) + 1)
    for a in left:
        current = [0]
        for index, b in enumerate(right, 1):
            current.append(
                previous[index - 1] + 1
                if a == b
                else max(previous[index], current[-1])
            )
        previous = current
    return previous[-1]


def _reconcile_tolerant(previous, current, min_overlap=3):
    exact = reconcile(previous, current, min_overlap)
    if exact is not None:
        return exact
    candidates = []
    for added in range(1, min(3, len(current) - min_overlap) + 1):
        tail = current[added:]
        expected = min(len(previous), len(tail))
        matches = _lcs_length(tail, previous)
        if matches >= min_overlap and matches >= expected - 1:
            candidates.append((matches, expected, -added, current[:added]))
    if not candidates:
        return None
    candidates.sort(reverse=True)
    return candidates[0][3]


def reconcile_panel(previous, current, min_overlap=3):
    """Reconcile a newest-first strip, tolerating one missing old token."""
    if not previous:
        return list(current), "initial"
    exact = reconcile(previous, current, min_overlap)
    if exact is not None:
        return exact, "exact"
    tolerant = _reconcile_tolerant(previous, current, min_overlap)
    if tolerant is None:
        return None, "ambigu"
    return tolerant, "tolérant"


def find_tesseract(executable=""):
    """Find a Windows or PATH installation without requiring manual setup."""
    candidates = []
    if executable and executable.strip():
        candidates.append(executable.strip().strip('"'))
    found = shutil.which("tesseract")
    if found:
        candidates.append(found)
    for variable in ("ProgramFiles", "PROGRAMFILES", "ProgramFiles(x86)"):
        root = os.environ.get(variable)
        if root:
            candidates.append(str(Path(root) / "Tesseract-OCR" / "tesseract.exe"))
    local = os.environ.get("LOCALAPPDATA")
    if local:
        candidates.append(
            str(Path(local) / "Programs" / "Tesseract-OCR" / "tesseract.exe")
        )
    for candidate in candidates:
        if Path(candidate).is_file():
            return str(Path(candidate))
    return None


def read_numbers(frame, executable="", newest_left=True):
    command = find_tesseract(executable)
    if not command:
        raise ValueError(
            "Tesseract absent. Relancez installer_windows.bat pour installer l’OCR."
        )
    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    gray = cv2.resize(gray, None, fx=3, fy=3, interpolation=cv2.INTER_CUBIC)
    gray = cv2.copyMakeBorder(gray, 12, 12, 12, 12, cv2.BORDER_CONSTANT, value=255)
    with tempfile.TemporaryDirectory(prefix="roulette-ocr-") as temp:
        path = Path(temp) / "panel.png"
        if not cv2.imwrite(str(path), gray):
            raise ValueError("Écriture temporaire OCR impossible.")
        result = subprocess.run(
            [
                command,
                str(path),
                "stdout",
                "--psm",
                "6",
                "-c",
                "tessedit_char_whitelist=0123456789 ",
                "tsv",
            ],
            capture_output=True,
            text=True,
            timeout=8,
            creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
        )
    if result.returncode:
        raise ValueError("Tesseract : " + result.stderr.strip()[-250:])
    tokens = []
    for row in csv.DictReader(io.StringIO(result.stdout), delimiter="\t"):
        text = row.get("text", "").strip()
        if not text:
            continue
        if (
            not text.isdigit()
            or len(text) > 2
            or not 0 <= int(text) <= 36
            or (len(text) > 1 and text.startswith("0"))
        ):
            raise ValueError(
                "OCR ambigu : nombre illisible ou chiffres fusionnés. Recalibrez le panneau."
            )
        confidence = float(row["conf"]) / 100
        tokens.append((int(row["top"]), int(row["left"]), int(text), confidence))
    if len(tokens) < 3 or min(t[3] for t in tokens) < 0.85:
        raise ValueError(
            "OCR insuffisant : au moins 3 numéros séparés avec score ≥ 85 % requis."
        )
    # Tesseract reading order is top-to-bottom then left-to-right.
    values = [t[2] for t in tokens]
    return values if newest_left else values[::-1]


class OCRWorker(QObject):
    ready = Signal(object, object)  # context token, newest-first snapshot
    error = Signal(object, str)

    @Slot(object, object, str, bool)
    def read(self, context, frame, executable, newest_left):
        try:
            self.ready.emit(context, read_numbers(frame, executable, newest_left))
        except Exception as exc:
            self.error.emit(context, str(exc))
