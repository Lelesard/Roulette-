"""Desktop tools for the existing manual accounting UI."""

import time
import sqlite3
from dataclasses import replace
from pathlib import Path

from PySide6.QtCore import Qt, QObject, QThread, QTimer, Signal, Slot, QMetaObject
from PySide6.QtWidgets import (
    QHBoxLayout,
    QLabel,
    QComboBox,
    QSpinBox,
    QLineEdit,
    QCheckBox,
    QInputDialog,
    QFileDialog,
    QMessageBox,
)

from .capture import (
    CaptureWorker,
    brave_windows,
    crop_roi,
    detect_wheel_roi,
    to_image,
)
from .ocr import OCRWorker, find_tesseract
from .experimental import (
    CandidateTracker,
    RotorTracker,
    direction_label,
    validate_ball_direction,
)
from .measurements import MeasurementRecorder
from .scene import SceneObserver
from .widgets import FrameView, RegionCalibrationDialog, LivePreviewDialog


class AnalysisWorker(QObject):
    ready = Signal(object, object)
    error = Signal(object, str)

    def __init__(self):
        super().__init__()
        self.tracker = CandidateTracker()
        self.rotor = RotorTracker()
        self.context = None

    @Slot(object, object, float)
    def analyze(self, context, frame, seconds):
        try:
            if context != self.context:
                self.tracker.reset()
                self.rotor.reset()
                self.context = context
            rotor = self.rotor.analyze(frame, seconds)
            ball = validate_ball_direction(
                self.tracker.analyze(frame, seconds), rotor
            )
            self.ready.emit(
                context,
                replace(
                    ball,
                    rotor_omega=rotor.omega,
                    rotor_confidence=rotor.confidence,
                    rotor_message=rotor.message,
                ),
            )
        except Exception as exc:
            self.error.emit(context, str(exc))


class SceneWorker(QObject):
    ready = Signal(object, object)
    error = Signal(object, str)

    def __init__(self):
        super().__init__()
        self.observer = SceneObserver()
        self.context = None

    @Slot(object, object, float)
    def analyze(self, context, frame, seconds):
        try:
            if context[:4] != self.context:
                self.observer.reset()
                self.context = context[:4]
            self.ready.emit(context, self.observer.analyze(frame, seconds))
        except Exception as exc:
            self.error.emit(context, str(exc))


class DesktopTools:
    """Mixin: signals are declared on Window, a QObject subclass."""

    def make_desktop(self):
        self.capture_active = False
        self.source_epoch = 0
        self.latest_frame = None
        self.latest_kind = None
        self.last_capture_stamp = None
        self.last_ocr = 0.0
        self.ocr_busy = False
        self.ocr_candidate = None
        self.ocr_stable = 0
        self.ocr_proposal = None
        self.ocr_armed = True
        self.ocr_last_seen = 0.0
        self.ocr_absent_count = 0
        self.analysis_busy = False
        self.last_analysis = 0.0
        self.scene_busy = False
        self.last_scene = 0.0
        self.camera_epoch = 0
        self.dynamic_wheel_roi = None
        self.ball_state = "non mesurée"
        self.rotor_state = "non mesuré"
        self.last_ball_direction = None
        self.last_rotor_direction = None
        self.measurement_recorder = MeasurementRecorder(
            self.capture_log_path.with_name("roulette-measurements-v26.json")
        )
        for name in ("Deutsches Roulette", "VIP Roulette", "Table manuelle"):
            if name not in self.store.profile_names():
                self.store.save_profile(name, {})
        self.direct = self.page("Direct")
        self.direct.addWidget(
            QLabel(
                "Capture de l’écran visible uniquement. Gardez Brave au premier plan, sans autre fenêtre devant la roulette."
            )
        )
        row = QHBoxLayout()
        self.direct.addLayout(row)
        self.brave_list = QComboBox()
        row.addWidget(self.brave_list, 1)
        self.button(row, "Actualiser Brave", self.list_brave)
        self.capture_rate = QSpinBox()
        self.capture_rate.setRange(1, 30)
        self.capture_rate.setValue(self.store.setting("capture_fps", 10))
        row.addWidget(QLabel("FPS cible"))
        row.addWidget(self.capture_rate)
        self.button(row, "Démarrer", self.start_capture)
        self.button(row, "Arrêter", self.stop_capture)
        self.automatic_scene = QCheckBox("Analyse automatique")
        self.automatic_scene.setChecked(self.store.setting("automatic_scene", True))
        self.automatic_scene.toggled.connect(self.toggle_automatic_scene)
        row.addWidget(self.automatic_scene)
        self.experimental_enabled = QCheckBox("Bille expérimentale")
        self.experimental_enabled.setChecked(
            self.store.setting("experimental_ball", False)
        )
        self.experimental_enabled.toggled.connect(self.toggle_experimental_ball)
        row.addWidget(self.experimental_enabled)
        self.live_image = FrameView()
        self.direct.addWidget(self.live_image, 1)
        self.live_image.selected.connect(self.save_roi)
        self.capture_controls(self.direct, self.live_image)
        self.live_preview_dialog = None
        self.capture_status = QLabel(
            "Capture arrêtée • bille : non mesurée • rotor : non mesuré"
        )
        self.capture_status.setWordWrap(True)
        self.direct.addWidget(self.capture_status)
        self.scene_status = QLabel(
            "Scène : en attente • le cadre dynamique exige trois observations concordantes"
        )
        self.scene_status.setWordWrap(True)
        self.direct.addWidget(self.scene_status)
        self.estimate_status = QLabel("Aucune estimation fiable")
        self.estimate_status.setStyleSheet("font-size:22px;color:#f9bf66;")
        self.direct.addWidget(self.estimate_status)
        self.direct_summary = QLabel()
        self.direct_summary.setWordWrap(True)
        self.direct.addWidget(self.direct_summary)
        row = QHBoxLayout()
        self.direct.addLayout(row)
        self.button(
            row,
            "Saisir les mises / Racetrack",
            lambda: self.tabs.setCurrentWidget(self.manual.tab_widget),
        )
        self.button(
            row,
            "Historique",
            lambda: self.tabs.setCurrentWidget(self.history.tab_widget),
        )
        self.button(
            row, "Bankroll", lambda: self.tabs.setCurrentWidget(self.finance.tab_widget)
        )
        self.make_profiles()
        self.make_ocr_settings()
        self.capture_thread = QThread(self)
        self.capture_worker = CaptureWorker()
        self.capture_worker.log = self.capture_log
        self.capture_worker.moveToThread(self.capture_thread)
        self.capture_thread.finished.connect(self.capture_worker.deleteLater)
        self.start_capture_signal.connect(self.capture_worker.start)
        self.stop_capture_signal.connect(self.capture_worker.stop)
        self.preview_timer = QTimer(self)
        self.preview_timer.setInterval(16)
        self.preview_timer.timeout.connect(self.poll_capture)
        self.preview_timer.start()
        self.capture_worker.error.connect(
            self.capture_error, Qt.ConnectionType.QueuedConnection
        )
        self.capture_thread.start()
        self.ocr_thread = QThread(self)
        self.ocr_worker = OCRWorker()
        self.ocr_worker.moveToThread(self.ocr_thread)
        self.ocr_thread.finished.connect(self.ocr_worker.deleteLater)
        self.ocr_request.connect(self.ocr_worker.read)
        self.ocr_worker.ready.connect(
            self.ocr_ready, Qt.ConnectionType.QueuedConnection
        )
        self.ocr_worker.error.connect(
            self.ocr_error, Qt.ConnectionType.QueuedConnection
        )
        self.ocr_thread.start()
        self.analysis_thread = QThread(self)
        self.analysis_worker = AnalysisWorker()
        self.analysis_worker.moveToThread(self.analysis_thread)
        self.analysis_thread.finished.connect(self.analysis_worker.deleteLater)
        self.analysis_request.connect(self.analysis_worker.analyze)
        self.analysis_worker.ready.connect(
            self.analysis_ready, Qt.ConnectionType.QueuedConnection
        )
        self.analysis_worker.error.connect(
            self.analysis_error, Qt.ConnectionType.QueuedConnection
        )
        self.analysis_thread.start()
        self.scene_thread = QThread(self)
        self.scene_worker = SceneWorker()
        self.scene_worker.moveToThread(self.scene_thread)
        self.scene_thread.finished.connect(self.scene_worker.deleteLater)
        self.scene_request.connect(self.scene_worker.analyze)
        self.scene_worker.ready.connect(
            self.scene_ready, Qt.ConnectionType.QueuedConnection
        )
        self.scene_worker.error.connect(
            self.scene_error, Qt.ConnectionType.QueuedConnection
        )
        self.scene_thread.start()
        # Reorder the nine functional pages, retaining their existing widgets.
        pages = {
            self.tabs.tabText(i): self.tabs.widget(i) for i in range(self.tabs.count())
        }
        self.tabs.clear()
        for name in (
            "Direct",
            "Racetrack",
            "Historique",
            "Bankroll",
            "Statistiques",
            "Vidéos et tests",
            "Tables et profils",
            "Paramètres",
            "Diagnostics",
        ):
            self.tabs.addTab(pages[name], name)
        self.sync_profile()

    def toggle_automatic_scene(self, enabled):
        self.store.save_setting("automatic_scene", enabled)
        self.scene_busy = False
        self.camera_epoch += 1
        self.dynamic_wheel_roi = None
        self.clear_dynamic_scene()
        self.scene_status.setText(
            "Scène : recherche automatique active"
            if enabled
            else "Scène : analyse automatique désactivée"
        )

    def toggle_experimental_ball(self, enabled):
        if not enabled:
            self.measurement_recorder.finish("suivi expérimental désactivé")
        self.store.save_setting("experimental_ball", enabled)
        self.analysis_busy = False
        self.camera_epoch += 1
        self.ball_state = "non mesurée"
        self.rotor_state = "non mesuré"
        self.last_ball_direction = None
        self.last_rotor_direction = None
        for view in (self.live_image, self.video_image):
            view.point = None
            view.update()
        if hasattr(self, "track_status"):
            self.track_status.setText(
                "Suivi bille expérimental activé • en attente d’une roue stable"
                if enabled
                else "Suivi bille désactivé • Aucune estimation fiable"
            )

    def clear_dynamic_scene(self):
        if not hasattr(self, "live_image"):
            return
        for view in (self.live_image, self.video_image):
            view.regions.pop("wheel_dynamic", None)
            view.regions.pop("wheel_candidate", None)
            view.point = None
            view.update()

    def capture_controls(self, layout, view):
        row = QHBoxLayout()
        layout.addLayout(row)
        self.button(
            row, "Calibrer le cylindre", lambda: self.begin_roi(view, "wheel_roi")
        )
        self.button(
            row, "Détecter le cylindre", lambda: self.auto_calibrate_wheel(view)
        )
        self.button(
            row,
            "Calibrer le résultat temporaire",
            lambda: self.begin_roi(view, "results_roi"),
        )
        self.button(row, "Agrandir l’aperçu", self.open_live_preview)
        self.button(row, "Effacer le calibrage", self.clear_calibration)

    def open_live_preview(self):
        if self.live_image.image is None:
            raise ValueError("Démarrez la capture avant d’agrandir l’aperçu.")
        if self.live_preview_dialog is None:
            self.live_preview_dialog = LivePreviewDialog(self)
            self.live_preview_dialog.selected.connect(self.save_large_preview_roi)
            self.live_preview_dialog.detect_wheel_requested.connect(
                lambda: self.auto_calibrate_wheel(self.live_preview_dialog.viewer)
            )
            self.live_preview_dialog.clear_requested.connect(self.clear_calibration)
            self.live_preview_dialog.finished.connect(
                lambda: setattr(self, "live_preview_dialog", None)
            )
        self.live_preview_dialog.viewer.regions = dict(self.live_image.regions)
        self.live_preview_dialog.set_image(self.live_image.image)
        self.live_preview_dialog.showMaximized()
        self.live_preview_dialog.raise_()
        self.live_preview_dialog.activateWindow()

    def save_large_preview_roi(self, selection):
        self.save_roi(selection)
        if selection[0] == "results_roi":
            self.store.reset_ocr_baseline(self.sid)
            self.ocr_armed = True
            self.ocr_last_seen = 0.0
            self.ocr_absent_count = 0
            self.set_ocr_status(
                "OCR : zone du résultat temporaire enregistrée sur l’aperçu agrandi "
                "• en attente de son apparition"
            )
        if self.live_preview_dialog is not None:
            self.live_preview_dialog.viewer.regions = dict(self.live_image.regions)
            self.live_preview_dialog.viewer.update()

    def active_table(self):
        row = self.store.db.execute(
            "SELECT table_name FROM sessions WHERE id=?", (self.sid,)
        ).fetchone()
        return row[0] if row else "Table manuelle"

    def sync_profile(self):
        name = self.active_table()
        if name not in self.store.profile_names():
            self.store.save_profile(name, {})
        if not hasattr(self, "profiles"):
            return
        self.profiles.blockSignals(True)
        self.profiles.clear()
        self.profiles.addItems(self.store.profile_names())
        self.profiles.setCurrentText(name)
        self.profiles.blockSignals(False)
        self.show_profile()
        regions = {
            k: v
            for k, v in self.store.profile(name).items()
            if k in ("wheel_roi", "results_roi")
        }
        for view in (self.live_image, self.video_image):
            view.regions = regions
            view.point = None
            view.update()
        self.newest_left.blockSignals(True)
        self.newest_left.setChecked(self.store.profile(name).get("newest_left", True))
        self.newest_left.blockSignals(False)
        self.ocr_proposal = None
        self.ocr_candidate = None
        self.ocr_stable = 0
        self.set_ocr_status("Aucun résultat OCR à valider. Profil actif : " + name)

    def make_profiles(self):
        page = self.page("Tables et profils")
        row = QHBoxLayout()
        page.addLayout(row)
        self.profiles = QComboBox()
        row.addWidget(self.profiles)
        self.profiles.currentTextChanged.connect(self.show_profile)
        self.button(row, "Créer un profil", self.create_profile)
        self.profile_detail = QLabel()
        self.profile_detail.setWordWrap(True)
        page.addWidget(self.profile_detail)
        self.profile_note = QLineEdit()
        self.profile_note.setPlaceholderText("Notes de table / caméra")
        page.addWidget(self.profile_note)
        self.button(page, "Sauvegarder la note", self.save_profile_note)
        page.addWidget(
            QLabel(
                "Chaque session conserve sa table. Créez une nouvelle session pour changer de table.\nLe calibrage utilise les coordonnées relatives à l’image et doit être refait après un zoom,\nun changement de disposition ou une caméra différente.\nPour le suivi expérimental, encadrez précisément l’ellipse du cylindre, sans le panneau de résultats."
            )
        )
        page.addStretch()

    def show_profile(self):
        name = self.profiles.currentText()
        config = self.store.profile(name)
        self.profile_detail.setText(
            "Profil consulté : "
            + name
            + "\n"
            + str({k: v for k, v in config.items() if k != "note"})
            + "\nProfil actif de la session : "
            + self.active_table()
        )
        self.profile_note.setText(config.get("note", ""))

    def create_profile(self):
        name, ok = QInputDialog.getText(self, "Nouveau profil", "Nom de la table")
        if not ok or not name.strip():
            return
        name = name.strip()
        if name in self.store.profile_names():
            raise ValueError("Ce profil existe déjà.")
        self.store.save_profile(name, {})
        self.profiles.addItem(name)
        self.profiles.setCurrentText(name)

    def save_profile_note(self):
        name = self.profiles.currentText()
        config = self.store.profile(name)
        config["note"] = self.profile_note.text()
        self.store.save_profile(name, config)

    def begin_roi(self, view, mode):
        if view.image is None:
            raise ValueError("Affichez une image avant de calibrer.")
        if mode == "results_roi":
            selection = RegionCalibrationDialog.select_region(
                self, view.image, mode
            )
            if selection is not None:
                self.save_roi(selection)
                self.store.reset_ocr_baseline(self.sid)
                self.ocr_armed = True
                self.ocr_last_seen = 0.0
                self.ocr_absent_count = 0
                self.set_ocr_status(
                    "OCR : zone du résultat temporaire enregistrée • attente de son apparition"
                )
            return
        view.mode = mode
        view.setCursor(Qt.CursorShape.CrossCursor)
        view.update()

    def auto_calibrate_wheel(self, view):
        frame = self.latest_frame
        if frame is None or view.image is None:
            raise ValueError("Affichez une image avant de détecter le cylindre.")
        roi, confidence = detect_wheel_roi(frame)
        previous = dict(view.regions)
        view.regions["wheel_candidate"] = roi
        view.update()
        answer = QMessageBox.question(
            self,
            "Cylindre détecté",
            "Le cadre vert entoure-t-il toute la roue ?\n"
            f"Score géométrique : {confidence * 100:.0f} %",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
            QMessageBox.StandardButton.No,
        )
        view.regions = previous
        if answer != QMessageBox.StandardButton.Yes:
            view.update()
            self.capture_status.setText(
                "Proposition refusée • calibrez manuellement ou attendez une autre caméra."
            )
            return
        self.save_roi(("wheel_roi", roi))
        self.capture_status.setText(
            f"Cylindre calibré automatiquement • score géométrique {confidence * 100:.0f} %"
        )

    def save_roi(self, data):
        mode, roi = data
        name = self.active_table()
        config = self.store.profile(name)
        config[mode] = roi
        self.store.save_profile(name, config)
        self.source_epoch += 1
        self.sync_profile()

    def clear_calibration(self):
        name = self.active_table()
        config = self.store.profile(name)
        for key in ("wheel_roi", "results_roi"):
            config.pop(key, None)
        self.store.save_profile(name, config)
        self.source_epoch += 1
        self.sync_profile()

    def list_brave(self):
        windows = brave_windows()
        self.brave_list.clear()
        for w in windows:
            self.brave_list.addItem(w.title, w.handle)
        if not windows:
            self.capture_status.setText(
                "Aucune fenêtre Brave visible. Ouvrez Brave puis actualisez."
            )

    def start_capture(self):
        if self.brave_list.currentData() is None:
            self.list_brave()
        handle = self.brave_list.currentData()
        if handle is None:
            return
        self.measurement_recorder.finish("nouveau démarrage de capture")
        self.timer.stop()
        self.source_epoch += 1
        self.camera_epoch += 1
        self.dynamic_wheel_roi = None
        self.ball_state = "non mesurée"
        self.rotor_state = "non mesuré"
        self.last_ball_direction = None
        self.last_rotor_direction = None
        self.clear_dynamic_scene()
        self.capture_active = True
        self.latest_frame = None
        self.store.save_setting("capture_fps", self.capture_rate.value())
        self.last_capture_stamp = None
        self.capture_count = 0
        self.capture_started_at = time.monotonic()
        self.capture_stale = False
        self.capture_log.info("ui.start")
        self.start_capture_signal.emit(handle, self.capture_rate.value())
        self.capture_status.setText("Démarrage de la capture visible…")
        self.scene_status.setText("Scène : recherche de la roue et de la caméra…")

    def stop_capture(self):
        self.capture_log.info("ui.stop")
        self.measurement_recorder.finish("capture arrêtée")
        self.capture_active = False
        self.source_epoch += 1
        self.camera_epoch += 1
        self.dynamic_wheel_roi = None
        self.clear_dynamic_scene()
        self.latest_frame = None
        self.stop_capture_signal.emit()
        self.capture_status.setText("Capture arrêtée • Aucune estimation fiable")
        self.scene_status.setText("Scène : analyse arrêtée")

    @Slot(str)
    def capture_error(self, message):
        self.capture_log.error("ui.capture_error %s", message)
        self.capture_active = False
        self.source_epoch += 1
        self.latest_frame = None
        self.capture_status.setText(message)

    def poll_capture(self):
        packet = self.capture_worker.take_frame()
        if not self.capture_active:
            return
        if packet is None:
            since = self.last_capture_stamp or self.capture_started_at
            if since is not None and time.monotonic() - since > 3:
                if not self.capture_stale:
                    self.capture_log.error("ui.stalled last_frame=%s", getattr(self, "capture_count", 0))
                    self.capture_stale = True
                self.capture_status.setText("Aucune nouvelle image depuis plus de 3 s. Exportez le journal dans Diagnostics.")
            return
        try:
            self.capture_log.info("ui.frame.begin")
            self.capture_frame(*packet)
            self.capture_stale = False
            self.capture_log.info("ui.frame.end image=%s", self.capture_count)
        except Exception as exc:
            self.capture_log.exception("ui.preview_failure")
            self.stop_capture()
            self.capture_status.setText("Erreur d’aperçu : " + str(exc))

    @Slot(object, float, float)
    def capture_frame(self, frame, stamp, latency):
        if not self.capture_active:
            return
        image = to_image(frame)
        self.live_image.set_image(image)
        if self.live_preview_dialog is not None and self.live_preview_dialog.isVisible():
            self.live_preview_dialog.viewer.regions = dict(self.live_image.regions)
            self.live_preview_dialog.set_image(image)
        fps = (
            1 / (stamp - self.last_capture_stamp)
            if self.last_capture_stamp and stamp > self.last_capture_stamp
            else 0
        )
        self.last_capture_stamp = stamp
        self.capture_count = getattr(self, "capture_count", 0) + 1
        self.ball_state = self.remembered_direction(
            self.last_ball_direction, "non mesurée"
        )
        self.rotor_state = self.remembered_direction(
            self.last_rotor_direction, "non mesuré"
        )
        self.capture_status.setText(
            f"Image {self.capture_count} • Capture {frame.shape[1]} × {frame.shape[0]} • {fps:.1f} FPS • capture {latency:.1f} ms • âge {max(0, time.monotonic() - stamp) * 1000:.1f} ms • bille : {self.ball_state} • rotor : {self.rotor_state}"
        )
        self.receive_source(frame, stamp, "live")

    def make_ocr_settings(self):
        self.settings_page.addWidget(
            QLabel("OCR local automatique — Tesseract installé avec le Tracker")
        )
        saved_tesseract = self.store.setting("tesseract", "")
        resolved_tesseract = find_tesseract(saved_tesseract)
        detected_tesseract = resolved_tesseract or saved_tesseract
        self.tesseract = QLineEdit(detected_tesseract)
        self.tesseract.setPlaceholderText(
            r"C:\Program Files\Tesseract-OCR\tesseract.exe (vide : PATH)"
        )
        self.settings_page.addWidget(self.tesseract)
        self.tesseract.editingFinished.connect(
            lambda: self.store.save_setting("tesseract", self.tesseract.text())
        )
        self.ocr_enabled = QCheckBox(
            "Lire automatiquement le résultat temporaire près des jetons"
        )
        self.ocr_enabled.setChecked(self.store.setting("ocr_enabled", False))
        self.settings_page.addWidget(self.ocr_enabled)
        self.ocr_auto = QCheckBox(
            "Ajouter automatiquement après deux lectures stables concordantes"
        )
        self.ocr_auto.setChecked(self.store.setting("ocr_auto", False))
        self.settings_page.addWidget(self.ocr_auto)
        self.newest_left = QCheckBox()
        self.newest_left.setChecked(True)
        self.ocr_enabled.toggled.connect(self.toggle_ocr_enabled)
        self.ocr_auto.toggled.connect(
            lambda enabled: self.store.save_setting("ocr_auto", enabled)
        )
        self.newest_left.toggled.connect(self.save_ocr_direction)
        self.ocr_review = QLabel()
        self.ocr_review.setWordWrap(True)
        self.settings_page.addWidget(self.ocr_review)
        self.ocr_diagnostic = QLabel("OCR v26 : en attente")
        self.ocr_diagnostic.setWordWrap(True)
        self.diagnostic_page.addWidget(self.ocr_diagnostic)
        if resolved_tesseract:
            self.set_ocr_status("OCR : Tesseract détecté • prêt à lire le panneau")
        else:
            self.set_ocr_status(
                "OCR : Tesseract absent • relancez installer_windows.bat"
            )
        row = QHBoxLayout()
        self.settings_page.addLayout(row)
        self.button(row, "Valider les résultats OCR proposés", self.accept_ocr)
        self.button(row, "Ignorer / relire", self.reset_ocr_proposal)
        self.settings_page.addWidget(
            QLabel(
                "L’OCR n’engage et ne règle aucune mise. Le résultat temporaire doit être lu deux fois.\nIl est ajouté une seule fois, puis le Tracker attend sa disparition avant de se réarmer. Deux sorties identiques consécutives restent ainsi distinguables."
            )
        )
        self.settings_page.addWidget(
            QLabel(
                "Le suivi de bille expérimental se commande dans Direct. Un point "
                "lumineux suivi n’est pas une bille validée."
            )
        )
        self.track_status = QLabel(
            "Suivi désactivé • rotor non mesuré • Aucune estimation fiable"
        )
        self.track_status.setWordWrap(True)
        self.diagnostic_page.addWidget(self.track_status)
        self.measurement_status = QLabel(self.measurement_recorder.status())
        self.measurement_status.setWordWrap(True)
        self.diagnostic_page.addWidget(self.measurement_status)
        row = QHBoxLayout()
        self.diagnostic_page.addLayout(row)
        self.button(row, "Terminer le lancer mesuré", self.finish_measurement_run)
        self.button(row, "Exporter les mesures v26", self.export_measurements)
        self.settings_page.addStretch()
        self.button(
            self.diagnostic_page,
            "Sauvegarder toute la base SQLite",
            self.backup_database,
        )

    def backup_database(self):
        path, _ = QFileDialog.getSaveFileName(
            self,
            "Sauvegarde complète",
            "roulette-sauvegarde.sqlite3",
            "SQLite (*.sqlite3)",
        )
        if not path:
            return
        source = self.store.db.execute("PRAGMA database_list").fetchone()[2]
        if Path(path).resolve() == Path(source).resolve():
            raise ValueError("Choisissez un autre fichier que la base active.")
        with sqlite3.connect(path) as target:
            self.store.db.backup(target)

    def finish_measurement_run(self):
        self.measurement_recorder.finish("fin manuelle")
        self.measurement_status.setText(self.measurement_recorder.status())

    def export_measurements(self):
        path, _ = QFileDialog.getSaveFileName(
            self,
            "Exporter les mesures des lancers",
            "roulette-mesures-v26.json",
            "JSON (*.json)",
        )
        if not path:
            return
        self.measurement_recorder.export(path)
        self.measurement_status.setText(
            self.measurement_recorder.status() + " • export terminé"
        )

    def reset_ocr_proposal(self):
        self.source_epoch += 1
        self.ocr_candidate = None
        self.ocr_stable = 0
        self.ocr_proposal = None
        self.ocr_armed = True
        self.ocr_last_seen = 0.0
        self.ocr_absent_count = 0
        self.set_ocr_status(
            "Proposition effacée • en attente de nouvelles lectures"
        )

    def set_ocr_status(self, text):
        self.ocr_review.setText(text)
        if hasattr(self, "ocr_diagnostic"):
            self.ocr_diagnostic.setText("OCR v26 : " + text.removeprefix("OCR : "))

    def toggle_ocr_enabled(self, enabled):
        self.store.save_setting("ocr_enabled", enabled)
        self.reset_ocr_proposal()

    def save_ocr_direction(self, value):
        config = self.store.profile(self.active_table())
        config["newest_left"] = value
        self.store.save_profile(self.active_table(), config)
        self.reset_ocr_proposal()

    def receive_source(self, frame, seconds, kind):
        if self._closing:
            return
        if kind == "video" and self.capture_active:
            return
        if self.latest_kind != kind:
            self.source_epoch += 1
            self.latest_kind = kind
            self.reset_ocr_proposal()
        self.latest_frame = frame
        config = self.store.profile(self.active_table())
        clock = time.monotonic()
        context = (
            self.source_epoch,
            self.sid,
            kind,
            self.video_path if kind == "video" else "",
            self.camera_epoch,
        )
        if (
            self.automatic_scene.isChecked()
            and not self.scene_busy
            and clock - self.last_scene >= 0.55
        ):
            self.scene_busy = True
            self.last_scene = clock
            self.scene_request.emit(context, frame.copy(), seconds)
        if (
            self.ocr_enabled.isChecked()
            and not self.ocr_busy
            and clock - self.last_ocr >= 0.35
        ):
            if "results_roi" not in config:
                self.set_ocr_status(
                    "OCR : calibrez la zone où le résultat temporaire apparaît près des jetons."
                )
            else:
                try:
                    roi = crop_roi(frame, config["results_roi"]).copy()
                    self.ocr_busy = True
                    self.last_ocr = clock
                    self.ocr_request.emit(
                        context,
                        roi,
                        self.tesseract.text(),
                        self.newest_left.isChecked(),
                    )
                except ValueError as exc:
                    self.set_ocr_status(str(exc))
        if (
            self.experimental_enabled.isChecked()
            and not self.analysis_busy
            and clock - self.last_analysis > 0.05
        ):
            wheel_roi = self.dynamic_wheel_roi or config.get("wheel_roi")
            if wheel_roi is None:
                self.track_status.setText(
                    "Suivi suspendu : aucune zone de roue stable."
                )
            else:
                try:
                    roi = crop_roi(frame, wheel_roi).copy()
                    self.analysis_busy = True
                    self.last_analysis = clock
                    self.analysis_request.emit(context, roi, seconds)
                except ValueError as exc:
                    self.track_status.setText(str(exc))

    def context_valid(self, context):
        return (
            not self._closing
            and context[:2] == (self.source_epoch, self.sid)
            and (len(context) < 5 or context[4] == self.camera_epoch)
        )

    def scene_context_valid(self, context):
        return (
            not self._closing
            and context[:2] == (self.source_epoch, self.sid)
            and context[2] == self.latest_kind
        )

    @Slot(object, object)
    def scene_ready(self, context, observation):
        self.scene_busy = False
        if not self.scene_context_valid(context) or not self.automatic_scene.isChecked():
            return
        if observation.camera_changed:
            self.measurement_recorder.finish("changement de caméra")
            self.camera_epoch += 1
            self.analysis_busy = False
            self.dynamic_wheel_roi = None
            self.ball_state = "non mesurée"
            self.rotor_state = "non mesuré"
            self.last_ball_direction = None
            self.last_rotor_direction = None
            self.clear_dynamic_scene()
            self.track_status.setText(
                "Changement de caméra : suivi réinitialisé • Aucune estimation fiable"
            )
        view = self.live_image if context[2] == "live" else self.video_image
        view.regions.pop("wheel_candidate", None)
        view.regions.pop("wheel_dynamic", None)
        if observation.wheel_roi is not None:
            self.dynamic_wheel_roi = observation.wheel_roi
            view.regions["wheel_dynamic"] = observation.wheel_roi
        elif observation.candidate_roi is not None:
            self.dynamic_wheel_roi = None
            view.regions["wheel_candidate"] = observation.candidate_roi
        else:
            self.dynamic_wheel_roi = None
        view.update()
        self.scene_status.setText("Scène : " + observation.message)

    @Slot(object, str)
    def scene_error(self, context, message):
        self.scene_busy = False
        if self.scene_context_valid(context):
            self.dynamic_wheel_roi = None
            self.clear_dynamic_scene()
            self.scene_status.setText("Analyse de scène interrompue : " + message)

    @Slot(object, object)
    def ocr_ready(self, context, snapshot):
        self.ocr_busy = False
        if not self.context_valid(context) or not self.ocr_enabled.isChecked():
            return
        if len(snapshot) != 1:
            self.set_ocr_status(
                "OCR : plusieurs nombres détectés • recadrez uniquement le résultat temporaire"
            )
            self.ocr_candidate = None
            self.ocr_stable = 0
            return
        now = time.monotonic()
        self.ocr_last_seen = now
        self.ocr_absent_count = 0
        if not self.ocr_armed:
            self.set_ocr_status(
                f"OCR : résultat {snapshot[0]} déjà traité • attente de sa disparition"
            )
            return
        prefix = snapshot
        candidate = ("apparition", snapshot[0])
        if candidate == self.ocr_candidate:
            self.ocr_stable += 1
        else:
            self.ocr_candidate = candidate
            self.ocr_stable = 1
        if self.ocr_stable < 2:
            self.set_ocr_status(
                f"OCR : numéro lu {snapshot[0]} • attente d’une deuxième lecture identique"
            )
            return
        self.ocr_armed = False
        self.ocr_proposal = (context, snapshot, prefix)
        self.set_ocr_status(
            f"OCR : résultat temporaire {snapshot[0]} confirmé deux fois"
        )
        if self.ocr_auto.isChecked():
            self.accept_ocr()

    @Slot(object, str)
    def ocr_error(self, context, message):
        self.ocr_busy = False
        if self.context_valid(context):
            now = time.monotonic()
            result_absent = message.startswith("Résultat temporaire absent")
            if not result_absent:
                # The result card is present. Keep a first valid reading across
                # a temporarily blurred frame so a short display is not missed.
                self.set_ocr_status(
                    "OCR : carte visible mais numéro momentanément illisible • nouvelle lecture en cours"
                )
                return
            self.ocr_absent_count += 1
            if not self.ocr_armed and self.ocr_absent_count >= 2:
                self.ocr_armed = True
                self.ocr_candidate = None
                self.ocr_stable = 0
                self.ocr_proposal = None
                self.set_ocr_status(
                    "OCR : résultat disparu • prêt pour la prochaine apparition"
                )
                return
            if self.ocr_armed:
                self.ocr_candidate = None
                self.ocr_stable = 0
                self.ocr_proposal = None
            status = (
                "OCR : attente du résultat temporaire"
                if self.ocr_armed
                else "OCR : résultat traité • confirmation de sa disparition"
            )
            self.set_ocr_status(status)

    def accept_ocr(self):
        if not self.ocr_proposal:
            return
        context, snapshot, prefix = self.ocr_proposal
        if not self.context_valid(context):
            self.reset_ocr_proposal()
            return
        inserted = self.store.commit_ocr(self.sid, snapshot, prefix)
        result_linked = False
        if len(inserted) == 1:
            spin, number = inserted[0]
            result_linked = self.measurement_recorder.attach_result(
                number, spin, self.sid
            )
            self.measurement_status.setText(self.measurement_recorder.status())
        self.ocr_proposal = None
        self.offset = 0
        self.refresh()
        linked = " • lié au lancer mesuré" if result_linked else ""
        self.set_ocr_status(
            f"OCR : {len(prefix)} résultat(s) ajouté(s){linked}, sans règlement financier."
        )

    @Slot(object, object)
    def analysis_ready(self, context, track):
        self.analysis_busy = False
        if not self.context_valid(context):
            return
        now = time.monotonic()
        self.measurement_recorder.add(context, track, now)
        self.measurement_status.setText(self.measurement_recorder.status())
        current_ball = direction_label(track.omega)
        current_rotor = direction_label(track.rotor_omega)
        if track.omega is not None:
            self.last_ball_direction = (
                current_ball,
                track.omega,
                track.confidence,
                now,
            )
        if track.rotor_omega is not None:
            self.last_rotor_direction = (
                current_rotor,
                track.rotor_omega,
                track.rotor_confidence,
                now,
            )
        self.ball_state = self.remembered_direction(
            self.last_ball_direction, "non mesurée"
        )
        self.rotor_state = self.remembered_direction(
            self.last_rotor_direction, "non mesuré"
        )
        ball_omega = f"{track.omega:.2f}" if track.omega is not None else "—"
        ball_alpha = f"{track.alpha:.2f}" if track.alpha is not None else "—"
        rotor_omega = (
            f"{track.rotor_omega:.2f}" if track.rotor_omega is not None else "—"
        )
        self.track_status.setText(
            f"Bille maintenant : {current_ball} • {track.message}\n"
            f"Continuité bille : {track.confidence:.2f} • ω : {ball_omega} rad/s • α : {ball_alpha} rad/s²\n"
            f"Dernière direction bille : {self.ball_state}\n"
            f"Rotor maintenant : {current_rotor} • {track.rotor_message}\n"
            f"Confiance rotor : {track.rotor_confidence:.2f} • ω : {rotor_omega} rad/s\n"
            f"Dernière direction rotor : {self.rotor_state}\n"
            "Sens observés sur l’image affichée • Aucune estimation fiable"
        )
        roi = self.dynamic_wheel_roi or self.store.profile(
            self.active_table()
        ).get("wheel_roi")
        view = self.live_image if context[2] == "live" else self.video_image
        # Do not draw the yellow point for a newly born bright hypothesis.  A
        # zero-confidence point is useful internally while continuity grows,
        # but presenting it as the ball made reflections and deflectors look
        # like confirmed detections.
        if roi and track.point and track.confidence >= 0.15:
            frame = self.latest_frame
            if frame is not None:
                h, w = crop_roi(frame, roi).shape[:2]
                x, y = track.point
                view.point = (
                    roi[0] + x / w * roi[2],
                    roi[1] + y / h * roi[3],
                )
                view.update()
        else:
            view.point = None
            view.update()

    @Slot(object, str)
    def analysis_error(self, context, message):
        self.analysis_busy = False
        if self.context_valid(context):
            self.ball_state = "non mesurée"
            self.rotor_state = "non mesuré"
            self.last_ball_direction = None
            self.last_rotor_direction = None
            self.track_status.setText("Analyse interrompue : " + message)

    @staticmethod
    def remembered_direction(measurement, empty):
        if measurement is None:
            return empty
        label, _omega, _confidence, measured_at = measurement
        age = max(0.0, time.monotonic() - measured_at)
        if age < 0.8:
            return label
        return f"{label} (dernière mesure il y a {age:.1f} s)"

    def refresh_desktop(self):
        if not hasattr(self, "direct_summary"):
            return
        s = self.store.summary(self.sid)
        recent = self.store.spins(self.sid, 12)
        latest = self.store.db.execute(
            "SELECT amount FROM operations WHERE session_id=? AND kind='tour' AND voided=0 ORDER BY id DESC LIMIT 1",
            (self.sid,),
        ).fetchone()
        from .gui import euros

        self.direct_summary.setText(
            "Table : "
            + self.active_table()
            + " • derniers numéros : "
            + ", ".join(str(r["number"]) for r in recent)
            + f"\nBankroll : {euros(s['balance'])} • jeton : {self.chip.currentText()} € • en attente : {euros(sum(b['stake'] for b in self.bets))}\nDernier tour déclaré : "
            + (euros(latest[0]) if latest else "aucun")
            + " • fermeture des mises : non détectée"
        )

    def shutdown_desktop(self):
        self.preview_timer.stop()
        self.measurement_recorder.finish("fermeture de l’application")
        self.capture_active = False
        self.source_epoch += 1
        QMetaObject.invokeMethod(
            self.capture_worker, "stop", Qt.ConnectionType.BlockingQueuedConnection
        )
        for thread in (
            self.capture_thread,
            self.ocr_thread,
            self.analysis_thread,
            self.scene_thread,
        ):
            thread.quit()
            thread.wait()
