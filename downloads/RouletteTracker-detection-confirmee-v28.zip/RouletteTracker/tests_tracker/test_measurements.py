import json
import tempfile
import unittest
from pathlib import Path

from tracker.experimental import Track
from tracker.measurements import MeasurementRecorder


class MeasurementRecorderTests(unittest.TestCase):
    def track(self, seconds, ball=None, rotor=-0.2):
        return Track(
            seconds,
            point=(20.0, 30.0) if ball is not None else None,
            omega=ball,
            alpha=-0.3 if ball is not None else None,
            confidence=0.8 if ball is not None else 0.0,
            message="bille",
            rotor_omega=rotor,
            rotor_confidence=0.7 if rotor is not None else 0.0,
            rotor_message="rotor",
        )

    def test_records_preroll_finishes_and_attaches_manual_result(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "measurements.json"
            recorder = MeasurementRecorder(
                path, quiet_seconds=1.0, rotor_quiet_seconds=0.5,
                start_confirmations=1,
            )
            context = (1, 7, "live", "", 3)
            recorder.add(context, self.track(10.0), 100.0)
            recorder.add(context, self.track(10.2, ball=3.0), 100.2)
            self.assertIsNotNone(recorder.current)
            self.assertEqual(len(recorder.current["samples"]), 2)
            recorder.add(context, self.track(11.4), 101.4)
            self.assertIsNotNone(recorder.current)
            recorder.add(context, self.track(12.0, rotor=None), 102.0)
            self.assertIsNone(recorder.current)
            self.assertEqual(len(recorder.runs), 1)
            self.assertEqual(recorder.runs[0]["sample_count"], 4)
            self.assertTrue(recorder.attach_result(17, 42, session_id=7))
            self.assertEqual(recorder.runs[0]["result"], 17)
            self.assertFalse(recorder.attach_result(9, 43, session_id=8))

            exported = Path(tmp) / "export.json"
            recorder.export(exported)
            payload = json.loads(exported.read_text(encoding="utf-8"))
            self.assertEqual(payload["tracker_version"], "measurements-v28")
            self.assertEqual(payload["runs"][0]["result"], 17)
            self.assertNotIn("_received", json.dumps(payload))
            self.assertIn("elapsed_seconds", payload["runs"][0]["samples"][0])

    def test_exports_recent_samples_when_no_run_is_validated(self):
        with tempfile.TemporaryDirectory() as tmp:
            recorder = MeasurementRecorder(
                Path(tmp) / "measurements.json", start_confirmations=2
            )
            context = (1, 7, "live", "", 3)
            recorder.add(context, self.track(1.0, ball=2.0), 100.0)
            payload = recorder.payload()
            self.assertEqual(payload["runs"], [])
            self.assertEqual(len(payload["recent_rejected_samples"]), 1)
            self.assertEqual(
                payload["recent_rejected_samples"][0]["ball_omega_rad_s"], 2.0
            )
            self.assertNotIn(
                "_received", payload["recent_rejected_samples"][0]
            )

    def test_recovers_interrupted_active_run_and_separates_contexts(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "measurements.json"
            first = MeasurementRecorder(path, start_confirmations=1)
            first.add((1, 1, "live", "", 2), self.track(1.0, ball=2.0), 5.0)
            self.assertTrue(path.exists())

            recovered = MeasurementRecorder(path, start_confirmations=1)
            self.assertEqual(len(recovered.runs), 1)
            self.assertEqual(
                recovered.runs[0]["ended_reason"], "interruption de l’application"
            )
            recovered.add(
                (2, 2, "video", "ignored.mp4", 0),
                self.track(2.0, ball=-2.0),
                8.0,
            )
            self.assertEqual(recovered.current["session_id"], 2)
            recovered.add(
                (3, 3, "live", "", 1), self.track(2.1, ball=-2.0), 8.1
            )
            self.assertEqual(len(recovered.runs), 2)
            self.assertEqual(recovered.current["session_id"], 3)

    def test_keeps_one_run_when_ball_returns_while_rotor_is_still_measured(self):
        with tempfile.TemporaryDirectory() as tmp:
            recorder = MeasurementRecorder(
                Path(tmp) / "measurements.json",
                quiet_seconds=1.0,
                rotor_quiet_seconds=0.5,
                start_confirmations=1,
            )
            context = (1, 7, "live", "", 3)
            recorder.add(context, self.track(1.0, ball=3.0), 100.0)
            recorder.add(context, self.track(2.2), 101.2)
            self.assertIsNotNone(recorder.current)

            recorder.add(context, self.track(2.6, ball=1.5), 101.6)
            self.assertEqual(recorder.current["sequence"], 1)
            recorder.add(context, self.track(3.7, rotor=None), 102.7)

            self.assertIsNone(recorder.current)
            self.assertEqual(len(recorder.runs), 1)
            self.assertEqual(recorder.runs[0]["sample_count"], 4)

    def test_requires_stable_start_and_rearms_only_after_ball_clears(self):
        with tempfile.TemporaryDirectory() as tmp:
            recorder = MeasurementRecorder(
                Path(tmp) / "measurements.json",
                start_confirmations=2,
                rearm_seconds=1.0,
            )
            context = (1, 7, "live", "", 3)
            recorder.add(context, self.track(1.0, ball=2.0), 100.0)
            self.assertIsNone(recorder.current)
            recorder.add(context, self.track(1.1, ball=2.0), 100.1)
            self.assertIsNotNone(recorder.current)
            self.assertTrue(recorder.attach_result(18, 1, session_id=7))

            for index in range(5):
                recorder.add(
                    context,
                    self.track(1.3 + index / 10, ball=2.0),
                    100.3 + index / 10,
                )
            self.assertIsNone(recorder.current)

            recorder.add(context, self.track(2.0, rotor=None), 101.0)
            recorder.add(context, self.track(3.1, rotor=None), 102.1)
            for index in range(2):
                recorder.add(
                    context,
                    self.track(3.2 + index / 10, ball=-2.0),
                    102.2 + index / 10,
                )
            self.assertIsNotNone(recorder.current)
            self.assertEqual(recorder.current["sequence"], 2)


if __name__ == "__main__":
    unittest.main()
