# Détection confirmée v28 — 6 novembre 2026

La v27 pouvait afficher « non mesuré » pendant tout un tour car les données du
Legion Go ne conservaient le seuil de 25 % que pendant deux analyses successives.
La v28 exige donc deux confirmations concordantes au lieu de trois, sans réduire
le seuil de confiance ni réafficher les hypothèses faibles.

L'export de mesures contient maintenant `recent_rejected_samples`. Même si aucun
lancer n'est ouvert, les derniers candidats, leur confiance et les motifs de
rejet sont disponibles pour le diagnostic. Cela permet d'ajuster la détection à
partir de valeurs réelles sans rendre les faux reflets visibles.
