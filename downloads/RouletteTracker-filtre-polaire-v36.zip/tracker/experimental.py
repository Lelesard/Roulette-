"""Experimental multi-hypothesis ball candidate tracker.

The selected point is never treated as a validated ball label. Real roulette
reflections and rotor details can still create coherent false tracks.
"""

from collections import deque
from dataclasses import dataclass, replace
import math

import cv2
import numpy as np


@dataclass(frozen=True)
class Track:
    seconds: float
    point: tuple | None = None
    angle: float | None = None
    omega: float | None = None
    alpha: float | None = None
    confidence: float = 0.0
    message: str = "Aucune bille validée"
    rotor_omega: float | None = None
    rotor_confidence: float = 0.0
    rotor_message: str = "Rotor non mesuré"
    rotor_angle: float | None = None
    radius: float | None = None
    identity_locked: bool = False
    new_launch: bool = False


@dataclass(frozen=True)
class RotorTrack:
    seconds: float
    omega: float | None = None
    confidence: float = 0.0
    message: str = "Rotor non mesuré"
    angle: float | None = None


def direction_label(omega):
    if omega is None or abs(omega) < 0.01:
        return "non mesuré"
    return "horaire à l’écran" if omega > 0 else "antihoraire à l’écran"


def validate_ball_direction(ball, rotor):
    """Publish a ball direction only when its speed is independent of the rotor."""
    if ball.omega is None:
        return ball
    if ball.radius is not None and ball.radius < 0.70 and ball.identity_locked:
        return replace(
            ball,
            omega=None,
            alpha=None,
            message=(
                f"Bille suivie sur le plateau • rayon {ball.radius:.2f} • "
                "vitesse séparée du rotor non publiée"
            ),
        )
    if ball.radius is not None and ball.radius < 0.70:
        return replace(
            ball,
            point=None,
            omega=None,
            alpha=None,
            message=(
                f"Candidat rejeté : rayon intérieur {ball.radius:.2f} • "
                "chiffre ou reflet du rotor probable"
            ),
        )
    candidate_direction = direction_label(ball.omega)
    if (
        rotor.omega is None
        and ball.radius is not None
        and ball.radius >= 0.70
        and ball.confidence >= 0.20
        and abs(ball.omega) >= 1.0
    ):
        return replace(
            ball,
            message=(
                f"{ball.message} • bille confirmée sur la piste extérieure "
                "indépendamment du rotor"
            ),
        )
    if ball.confidence < 0.25:
        return replace(
            ball,
            omega=None,
            alpha=None,
            message=(
                f"Candidat rejeté : continuité insuffisante "
                f"({ball.confidence * 100:.0f} % < 25 %)"
            ),
        )
    if rotor.omega is None:
        return replace(
            ball,
            omega=None,
            alpha=None,
            message=(
                f"Candidat {candidate_direction} en attente d’une direction rotor "
                "indépendante"
            ),
        )
    same_sign = math.copysign(1, ball.omega) == math.copysign(1, rotor.omega)
    minimum_independent_speed = (
        max(0.7, 5 * abs(rotor.omega)) if same_sign else 0.7
    )
    if abs(ball.omega) < minimum_independent_speed:
        return replace(
            ball,
            point=None,
            omega=None,
            alpha=None,
            message=(
                f"Candidat rejeté : vitesse {abs(ball.omega):.2f} rad/s trop proche "
                f"du rotor ({abs(rotor.omega):.2f} rad/s) • reflet rotor probable"
            ),
        )
    ratio = abs(ball.omega) / max(abs(rotor.omega), 0.01)
    relation = "même sens" if same_sign else "sens opposé"
    return replace(
        ball,
        message=(
            f"{ball.message} • mouvement indépendant du rotor confirmé "
            f"(vitesse ×{ratio:.1f}, {relation})"
        ),
    )


class RotorTracker:
    """Estimate rotor angular shift from a polar-unwrapped inner wheel band."""

    def __init__(self):
        self.reset()

    def reset(self):
        self.previous = None
        self.last_time = None
        self.speeds = deque(maxlen=18)

    @staticmethod
    def polar_band(frame, geometry=None):
        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        gray = cv2.GaussianBlur(gray, (3, 3), 0)
        h, w = gray.shape
        if geometry is None:
            center = (w / 2, h / 2)
            radius = min(h, w) * 0.48
        else:
            center = (float(geometry[0]), float(geometry[1]))
            radius = float(geometry[2])
        polar = cv2.warpPolar(
            gray,
            (96, 720),
            center,
            radius,
            cv2.WARP_POLAR_LINEAR,
        )
        # Ignore the hub and the outer ball track. Pocket/number features live in
        # the middle radial band and move with the rotor.
        band = polar[:, 30:78].astype(np.float32)
        band -= cv2.GaussianBlur(band, (0, 0), 3)
        band *= np.hanning(band.shape[0]).astype(np.float32)[:, None]
        return band

    def analyze(self, frame, seconds, geometry=None):
        band = self.polar_band(frame, geometry)
        if self.previous is None or self.last_time is None:
            self.previous, self.last_time = band, seconds
            return RotorTrack(seconds, message="Rotor : initialisation")
        dt = seconds - self.last_time
        if not 0 < dt < 0.35 or self.previous.shape != band.shape:
            self.reset()
            self.previous, self.last_time = band, seconds
            return RotorTrack(seconds, message="Rotor : suivi réinitialisé")
        (radial_shift, angular_shift), response = cv2.phaseCorrelate(
            self.previous, band
        )
        self.previous, self.last_time = band, seconds
        omega = angular_shift / band.shape[0] * 2 * math.pi / dt
        while self.speeds and seconds - self.speeds[0][0] > 0.9:
            self.speeds.popleft()
        if response < 0.025:
            return RotorTrack(
                seconds,
                message=(
                    "Rotor : détails insuffisants ou image ambiguë • "
                    f"corrélation {max(0.0, response):.2f}"
                ),
            )
        if abs(radial_shift) > 18:
            return RotorTrack(
                seconds,
                message=(
                    f"Rotor : déplacement radial {radial_shift:.1f} px, mesure rejetée • "
                    f"corrélation {response:.2f}"
                ),
            )
        if abs(omega) < 0.08:
            return RotorTrack(
                seconds,
                message=(
                    "Rotor immobile ou mouvement trop faible • "
                    f"corrélation {response:.2f}"
                ),
            )
        if abs(omega) > 28:
            return RotorTrack(
                seconds,
                message=(
                    f"Rotor : saut angulaire trop rapide ({omega:.1f} rad/s) • "
                    f"corrélation {response:.2f}"
                ),
            )
        self.speeds.append((seconds, float(omega), float(response)))
        if len(self.speeds) < 5:
            return RotorTrack(
                seconds,
                message=f"Rotor : continuité {len(self.speeds)}/5",
            )
        speeds = np.array([sample[1] for sample in self.speeds])
        responses = np.array([sample[2] for sample in self.speeds])
        median = float(np.median(speeds))
        direction_agreement = float(np.mean(np.sign(speeds) == np.sign(median)))
        spread = float(np.median(np.abs(speeds - median)))
        confidence = (
            min(1.0, max(0.0, float(np.median(responses))) / 0.20)
            * direction_agreement
            * max(0.0, min(1.0, 1 - spread / max(abs(median), 0.2)))
        )
        if direction_agreement < 0.8 or confidence < 0.25:
            return RotorTrack(
                seconds,
                message="Rotor : direction instable, mesure rejetée",
            )
        return RotorTrack(
            seconds,
            median,
            confidence,
            (
                f"Rotor {direction_label(median)} • {len(self.speeds)} mesures récentes • "
                f"corrélation médiane {float(np.median(responses)):.2f}"
            ),
        )


class ZeroTracker:
    """Track the green zero pocket as the rotor absolute angular reference."""

    def __init__(self):
        self.reset()

    def reset(self):
        self.samples = deque(maxlen=30)

    @staticmethod
    def detect(frame, geometry):
        if geometry is None:
            return None
        hsv = cv2.cvtColor(frame, cv2.COLOR_BGR2HSV)
        h, w = hsv.shape[:2]
        yy, xx = np.mgrid[:h, :w]
        cx, cy, wheel_radius = geometry
        radial = np.hypot(xx - cx, yy - cy) / max(wheel_radius, 1)
        angles = (np.arctan2(yy - cy, xx - cx) + 2 * math.pi) % (2 * math.pi)
        mask = (
            (radial > 0.48)
            & (radial < 0.72)
            & (hsv[:, :, 0] > 35)
            & (hsv[:, :, 0] < 95)
            & (hsv[:, :, 1] > 75)
            & (hsv[:, :, 2] > 45)
        )
        if int(np.count_nonzero(mask)) < 20:
            return None
        bins = np.zeros(360, dtype=np.float32)
        indices = (angles[mask] * 360 / (2 * math.pi)).astype(int) % 360
        weights = (
            hsv[:, :, 1][mask].astype(np.float32) / 255
            * hsv[:, :, 2][mask].astype(np.float32) / 255
        )
        np.add.at(bins, indices, weights)
        extended = np.r_[bins[-8:], bins, bins[:8]]
        smooth = np.convolve(extended, np.ones(17, np.float32), mode="valid")
        peak = int(np.argmax(smooth))
        contrast = float(smooth[peak] / max(float(np.mean(smooth)), 1e-6))
        if contrast < 4.0:
            return None
        return peak * 2 * math.pi / 360, contrast

    def analyze(self, frame, seconds, geometry):
        detected = self.detect(frame, geometry)
        if detected is None:
            return RotorTrack(seconds, message="Rotor : poche zéro verte non visible")
        raw_angle, contrast = detected
        if self.samples:
            previous = self.samples[-1][1]
            angle = raw_angle + round((previous - raw_angle) / (2 * math.pi)) * 2 * math.pi
        else:
            angle = raw_angle
        self.samples.append((float(seconds), float(angle), float(contrast)))
        while self.samples and seconds - self.samples[0][0] > 0.9:
            self.samples.popleft()
        if len(self.samples) < 5:
            return RotorTrack(
                seconds,
                message=f"Rotor : zéro vert {len(self.samples)}/5",
                angle=raw_angle,
            )
        times = np.array([sample[0] - seconds for sample in self.samples])
        values = np.array([sample[1] for sample in self.samples])
        slope, intercept = np.polyfit(times, values, 1)
        residual = float(np.sqrt(np.mean((slope * times + intercept - values) ** 2)))
        confidence = (
            min(1.0, float(np.median([s[2] for s in self.samples])) / 12)
            * max(0.0, min(1.0, 1 - residual / 0.12))
            * min(1.0, len(self.samples) / 12)
        )
        if residual > 0.12 or abs(slope) < 0.05 or abs(slope) > 12:
            return RotorTrack(
                seconds,
                message=f"Rotor : zéro vert instable • résidu {residual:.3f} rad",
                angle=raw_angle,
            )
        return RotorTrack(
            seconds,
            float(slope),
            confidence,
            (
                f"Rotor {direction_label(float(slope))} • zéro vert absolu • "
                f"résidu {residual:.3f} rad"
            ),
            raw_angle,
        )


class Hypothesis:
    def __init__(self, point):
        self.points = deque([point], maxlen=45)
        self.misses = 0
        seconds, angle, _x, _y, radius, _quality = point
        # One polar Kalman filter per visual hypothesis.  The state is
        # [unwrapped angle, angular speed, normalized radius, radial speed].
        # Candidate identity is still decided by the multi-hypothesis manager;
        # the filter only predicts and rejects incompatible measurements.
        self.state = np.array([[angle], [0.0], [radius], [0.0]], np.float64)
        self.covariance = np.diag([0.025, 16.0, 0.0036, 0.64]).astype(
            np.float64
        )
        self.observation = np.array(
            [[1.0, 0.0, 0.0, 0.0], [0.0, 0.0, 1.0, 0.0]], np.float64
        )
        self.measurement_noise = np.diag([0.055**2, 0.025**2]).astype(
            np.float64
        )
        self.filter_time = float(seconds)

    @staticmethod
    def _transition(dt):
        return np.array(
            [
                [1.0, dt, 0.0, 0.0],
                [0.0, 1.0, 0.0, 0.0],
                [0.0, 0.0, 1.0, dt],
                [0.0, 0.0, 0.0, 1.0],
            ],
            np.float64,
        )

    @staticmethod
    def _process_noise(dt, landing=False):
        # Piecewise-constant acceleration model.  Powers of dt keep the
        # uncertainty stable when the real capture rate varies.
        block = np.array(
            [[dt**4 / 4.0, dt**3 / 2.0], [dt**3 / 2.0, dt**2]],
            np.float64,
        )
        result = np.zeros((4, 4), np.float64)
        result[0:2, 0:2] = (18.0 if landing else 7.0) * block
        result[2:4, 2:4] = (1.8 if landing else 0.45) * block
        return result

    def predict_filter(self, seconds, landing=False):
        elapsed = float(seconds) - self.filter_time
        if elapsed <= 0:
            return float(self.state[0, 0]), float(self.state[2, 0])
        # A delayed UI/capture frame must increase uncertainty without making
        # a single enormous extrapolation.  Integrate it in bounded steps.
        remaining = min(elapsed, 0.60)
        while remaining > 1e-9:
            dt = min(0.15, remaining)
            transition = self._transition(dt)
            self.state = transition @ self.state
            self.covariance = (
                transition @ self.covariance @ transition.T
                + self._process_noise(dt, landing)
            )
            remaining -= dt
        self.filter_time = float(seconds)
        return float(self.state[0, 0]), float(self.state[2, 0])

    def innovation(self, candidate):
        _x, _y, raw_angle, radius, _quality = candidate
        reference = float(self.state[0, 0])
        angle = raw_angle + round((reference - raw_angle) / (2 * math.pi)) * 2 * math.pi
        measurement = np.array([[angle], [radius]], np.float64)
        residual = measurement - self.observation @ self.state
        innovation_covariance = (
            self.observation @ self.covariance @ self.observation.T
            + self.measurement_noise
        )
        try:
            distance = float(
                (residual.T @ np.linalg.solve(innovation_covariance, residual)).item()
            )
        except np.linalg.LinAlgError:
            return None
        return distance, measurement, residual, innovation_covariance

    def correct_filter(self, measurement, residual, innovation_covariance):
        gain = (
            self.covariance
            @ self.observation.T
            @ np.linalg.inv(innovation_covariance)
        )
        self.state = self.state + gain @ residual
        identity = np.eye(4, dtype=np.float64)
        remainder = identity - gain @ self.observation
        # Joseph form preserves a symmetric positive covariance after many
        # corrections and round-off errors.
        self.covariance = (
            remainder @ self.covariance @ remainder.T
            + gain @ self.measurement_noise @ gain.T
        )
        self.covariance = 0.5 * (self.covariance + self.covariance.T)

    def predict(self, seconds):
        last = self.points[-1]
        if len(self.points) < 2:
            return last[1]
        previous = self.points[-2]
        dt = last[0] - previous[0]
        omega = (last[1] - previous[1]) / dt if dt > 0 else 0.0
        return last[1] + omega * max(0.0, seconds - last[0])

    def add(self, seconds, candidate, filter_data=None):
        x, y, raw_angle, radius, quality = candidate
        predicted = self.predict(seconds)
        angle = raw_angle + round((predicted - raw_angle) / (2 * math.pi)) * 2 * math.pi
        if filter_data is None:
            filter_data = self.innovation(candidate)
        if filter_data is not None:
            _distance, measurement, residual, innovation_covariance = filter_data
            self.correct_filter(measurement, residual, innovation_covariance)
        self.points.append((seconds, angle, x, y, radius, quality))
        self.misses = 0


class CandidateTracker:
    """Track moving bright hypotheses in the normalized outer wheel ring."""

    def __init__(self):
        self.reset()

    def reset(self):
        self.points = deque(maxlen=45)
        self.hypotheses = []
        self.previous_small = None
        self.previous_gray = None
        self.last_time = None
        self.shape = None
        self.ball_lock = None
        self.ball_hypothesis = None
        self.ball_motion = None
        self.descent_started = None
        self.landing_last_time = None
        self.last_fast_time = None
        self.last_fast_speed = None
        self.wheel_geometry = None
        self.fixed_references = []

    @staticmethod
    def angular_distance(a, b):
        return abs((a - b + math.pi) % (2 * math.pi) - math.pi)

    def detect_wheel_geometry(self, gray):
        """Locate the physical bowl inside a possibly loose calibration box."""
        h, w = gray.shape
        if self.wheel_geometry is not None:
            return self.wheel_geometry
        blurred = cv2.medianBlur(gray, 7)
        minimum = min(h, w)
        circles = cv2.HoughCircles(
            blurred,
            cv2.HOUGH_GRADIENT,
            dp=1.2,
            minDist=minimum * 0.35,
            param1=120,
            param2=90,
            minRadius=round(minimum * 0.30),
            maxRadius=round(minimum * 0.49),
        )
        if circles is None:
            # Synthetic unit fixtures deliberately contain no photographed rim.
            if float(np.mean(gray)) < 20:
                self.wheel_geometry = (w / 2, h / 2, minimum * 0.48)
            return self.wheel_geometry
        choices = circles[0]
        center = np.array([w / 2, h / 2])
        cx, cy, radius = max(
            choices,
            key=lambda item: float(item[2]) - 0.35 * float(
                np.linalg.norm(item[:2] - center)
            ),
        )
        self.wheel_geometry = (float(cx), float(cy), float(radius))

        # Stable corner-like features in the fixed bowl include the metal
        # star/diamond deflectors. They anchor the photographed wheel and are
        # intentionally outside the moving rotor pocket band.
        yy, xx = np.mgrid[:h, :w]
        radial = np.hypot(xx - cx, yy - cy) / max(radius, 1)
        reference_mask = ((radial > 0.66) & (radial < 0.93)).astype(np.uint8) * 255
        features = cv2.goodFeaturesToTrack(
            gray,
            maxCorners=24,
            qualityLevel=0.08,
            minDistance=max(8, round(radius * 0.08)),
            mask=reference_mask,
            blockSize=7,
        )
        self.fixed_references = (
            [] if features is None else [tuple(map(float, p[0])) for p in features]
        )
        return self.wheel_geometry

    def candidates(self, gray, seconds):
        h, w = gray.shape
        yy, xx = np.mgrid[:h, :w]
        geometry = self.detect_wheel_geometry(gray)
        if geometry is None:
            return []
        center_x, center_y, wheel_radius = geometry
        nx, ny = (xx - center_x) / wheel_radius, (yy - center_y) / wheel_radius
        radius = np.hypot(nx, ny)
        contrast = cv2.subtract(gray, cv2.GaussianBlur(gray, (0, 0), 3))
        motion = (
            cv2.absdiff(gray, self.previous_gray)
            if self.previous_gray is not None and self.previous_gray.shape == gray.shape
            else np.zeros_like(gray)
        )
        # The moving white pocket digits are the strongest false positives on
        # real tables.  Never inspect their band before a real outer-ball
        # trajectory has established identity.  Once that identity exists we
        # briefly open the inner bowl so the same hypothesis can follow the
        # physical descent toward the pockets.
        locked_radius = (
            self.ball_hypothesis.points[-1][4]
            if self.ball_hypothesis is not None
            else None
        )
        descent_gate = (
            self.ball_hypothesis is not None
            and locked_radius is not None
            and locked_radius <= 0.78
            and self.last_fast_time is not None
            and seconds - self.last_fast_time <= 2.2
        ) or (
            self.landing_last_time is not None
            and seconds - self.landing_last_time <= 6.0
        ) or (
            self.descent_started is not None
            and seconds - self.descent_started <= 7.0
        )
        minimum_radius = 0.46 if descent_gate else 0.70
        mask = (
            (gray > 190)
            & (contrast > 12)
            & (radius > minimum_radius)
            # The photographed outer rail is slightly elliptical on real
            # tables.  A circular normalization therefore moves the same ball
            # between roughly 0.75 and 0.96 depending on its screen angle.
            & (radius < 0.97)
        ).astype(np.uint8) * 255
        mask = cv2.morphologyEx(
            mask,
            cv2.MORPH_OPEN,
            cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (3, 3)),
        )
        count, labels, stats, centers = cv2.connectedComponentsWithStats(mask)
        result = []
        for index in range(1, count):
            area = stats[index, cv2.CC_STAT_AREA]
            bw, bh = stats[index, cv2.CC_STAT_WIDTH : cv2.CC_STAT_HEIGHT + 1]
            if not (
                3 <= area <= max(18, h * w * 0.002)
                and 0.28 < bw / max(1, bh) < 3.6
            ):
                continue
            x, y = map(float, centers[index])
            component = labels == index
            brightness = float(np.mean(gray[component])) / 255
            movement = float(np.mean(motion[component])) / 255
            local_contrast = float(np.mean(contrast[component])) / 255
            radial = float(radius[round(y), round(x)])
            if (
                self.previous_gray is not None
                and self.last_fast_time is None
                and movement < 0.025
            ):
                continue
            radial_target = 0.84
            quality = (
                0.42 * brightness
                + 0.34 * min(1.0, movement * 3)
                + 0.18 * min(1.0, local_contrast * 4)
                + 0.06 * max(0.0, 1 - abs(radial - radial_target) / 0.28)
            )
            result.append(
                (
                    x,
                    y,
                    math.atan2(
                        (y - center_y) / wheel_radius,
                        (x - center_x) / wheel_radius,
                    ),
                    radial,
                    quality,
                )
            )
        return result

    def update_hypotheses(self, candidates, seconds):
        unused = set(range(len(candidates)))
        for hypothesis in sorted(
            self.hypotheses, key=lambda item: len(item.points), reverse=True
        ):
            locked_ball = hypothesis is self.ball_hypothesis
            maximum_age = 0.22
            if seconds - hypothesis.points[-1][0] > maximum_age:
                hypothesis.misses = 4
                continue
            landing = locked_ball and (
                self.descent_started is not None
                or hypothesis.points[-1][4] < 0.70
            )
            predicted, predicted_radius = hypothesis.predict_filter(
                seconds, landing=landing
            )
            # The last two real observations react faster than a smoothed
            # filter when the ball suddenly hits a deflector.  Keep that
            # proven v35 predictor for identity association; Kalman provides
            # uncertainty gating and missing-frame extrapolation.
            predicted = hypothesis.predict(seconds)
            previous_radius = hypothesis.points[-1][4]
            predicted_radius = previous_radius
            choices = []
            for index in unused:
                candidate = candidates[index]
                angle_cost = self.angular_distance(candidate[2], predicted)
                radius_cost = abs(candidate[3] - predicted_radius)
                maximum_angle = 0.85 if locked_ball else 1.25
                # Keep enough radial tolerance for perspective.  The ball is
                # on a circular rail physically, but that rail is an ellipse
                # in the captured image; a 0.055 limit lost it every quarter
                # turn on the two real recordings.
                maximum_radius = 0.12 if locked_ball else 0.12
                if locked_ball and candidate[3] < 0.70:
                    if self.descent_started is None:
                        # Crossing into the rotor band is accepted only as a
                        # smooth continuation from the lower edge of the bowl.
                        # This prevents a blurred outer ball from jumping to a
                        # white digit on the opposite-moving rotor.
                        maximum_angle = 0.28
                        maximum_radius = 0.09
                        if previous_radius > 0.78:
                            continue
                    else:
                        maximum_angle = 0.55
                        maximum_radius = 0.11
                if (
                    angle_cost <= maximum_angle
                    and radius_cost <= maximum_radius
                ):
                    filter_data = hypothesis.innovation(candidate)
                    if filter_data is None or filter_data[0] > 50.0:
                        continue
                    choices.append(
                        (
                            angle_cost
                            + radius_cost * 1.8
                            - candidate[4] * 0.12,
                            index,
                            filter_data,
                        )
                    )
            if choices:
                _cost, index, filter_data = min(choices)
                hypothesis.add(seconds, candidates[index], filter_data)
                unused.remove(index)
            else:
                hypothesis.misses += 1
        self.hypotheses = [item for item in self.hypotheses if item.misses <= 3]
        # A hypothesis is deleted after several blurred/missing frames. Keeping
        # its Python object as the ball identity made every future fitted track
        # get filtered out forever. Release that stale identity so the same
        # physical ball can be acquired again when it becomes visible.
        if (
            self.ball_hypothesis is not None
            and self.ball_hypothesis not in self.hypotheses
        ):
            self.ball_hypothesis = None
        for index in unused:
            x, y, angle, radius, quality = candidates[index]
            self.hypotheses.append(
                Hypothesis((seconds, angle, x, y, radius, quality))
            )
        self.hypotheses = sorted(
            self.hypotheses,
            key=lambda item: (len(item.points), -item.misses, item.points[-1][5]),
            reverse=True,
        )[:24]

    @staticmethod
    def fit(hypothesis, seconds):
        points = list(hypothesis.points)[-30:]
        if len(points) < 7 or points[-1][0] - points[0][0] < 0.18:
            return None
        times = np.array([point[0] - seconds for point in points])
        angles = np.array([point[1] for point in points])
        if np.max(np.abs(np.diff(angles))) > 1.8:
            return None
        coeff = np.polyfit(times, angles, 2)
        residual = float(
            np.sqrt(np.mean((np.polyval(coeff, times) - angles) ** 2))
        )
        omega = float(coeff[1])
        alpha = float(2 * coeff[0])
        if residual > 0.22 or not 0.35 <= abs(omega) <= 40:
            return None
        quality = float(np.mean([point[5] for point in points]))
        confidence = (
            max(0.0, min(1.0, 1 - residual / 0.22))
            * min(1.0, len(points) / 20)
            * min(1.0, abs(omega) / 3)
            * min(1.0, quality / 0.72)
        )
        return confidence, omega, alpha, residual

    def analyze(self, frame, seconds):
        h, w = frame.shape[:2]
        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        small = cv2.resize(gray, (64, 64))
        changed = (
            self.previous_small is not None
            and np.mean(cv2.absdiff(small, self.previous_small)) > 38
        )
        discontinuity = (
            self.last_time is not None and not 0 < seconds - self.last_time < 0.35
        )
        resized = self.shape is not None and self.shape != (h, w)
        if changed or discontinuity or resized:
            self.points.clear()
            self.hypotheses.clear()
            self.ball_lock = None
            self.ball_hypothesis = None
            self.ball_motion = None
            self.descent_started = None
            self.landing_last_time = None
            self.last_fast_time = None
            self.last_fast_speed = None
        elif (
            self.last_fast_time is not None
            and seconds - self.last_fast_time > 6.0
            and (
                self.landing_last_time is None
                or seconds - self.landing_last_time > 6.0
            )
        ):
            # The previous launch is over for tracking purposes. Without this
            # expiry, inner rotor-digit hypotheses from that launch remain in
            # the pool and can outrank the next ball appearing on the bowl.
            self.hypotheses.clear()
            self.ball_lock = None
            self.ball_hypothesis = None
            self.ball_motion = None
            self.descent_started = None
            self.landing_last_time = None
            self.last_fast_time = None
            self.last_fast_speed = None
        if resized:
            self.wheel_geometry = None
            self.fixed_references = []
        if changed or resized:
            self.previous_small = small
            self.previous_gray = gray
            self.last_time = seconds
            self.shape = (h, w)
            return Track(
                seconds, message="Changement de caméra / zoom : suivi réinitialisé"
            )

        candidates = self.candidates(gray, seconds)
        self.update_hypotheses(candidates, seconds)
        self.previous_small = small
        self.previous_gray = gray
        self.last_time = seconds
        self.shape = (h, w)

        fitted = []
        new_launch = False
        for hypothesis in self.hypotheses:
            if hypothesis.misses:
                continue
            result = self.fit(hypothesis, seconds)
            if result is not None:
                fitted.append((result[0], hypothesis, result))
        if self.ball_hypothesis is not None:
            # Identity is more important than a temporarily better numerical
            # fit.  A newly born rotor-digit track must never replace the outer
            # trajectory that established the ball lock.
            current_radius = self.ball_hypothesis.points[-1][4]
            outer_restart = [
                item
                for item in fitted
                if item[1] is not self.ball_hypothesis
                and item[1].points[-1][4] >= 0.70
                and item[0] >= 0.25
                and abs(item[2][1]) >= 1.0
            ]
            if (
                current_radius < 0.70
                and self.landing_last_time is not None
                and outer_restart
            ):
                # A coherent fast trajectory has appeared back on the outer
                # rail while the previous identity is rotating slowly in a
                # pocket.  This is the next launch on a rapid table.
                fitted = outer_restart
                self.ball_lock = None
                self.ball_hypothesis = None
                self.ball_motion = None
                self.descent_started = None
                self.landing_last_time = None
                self.last_fast_time = None
                self.last_fast_speed = None
                new_launch = True
            else:
                fitted = [
                    item for item in fitted if item[1] is self.ball_hypothesis
                ]
        elif self.landing_last_time is not None:
            outer_restart = [
                item
                for item in fitted
                if item[1].points[-1][4] >= 0.70
                and item[0] >= 0.25
                and abs(item[2][1]) >= 1.0
            ]
            if outer_restart:
                fitted = outer_restart
                self.ball_lock = None
                self.ball_motion = None
                self.descent_started = None
                self.landing_last_time = None
                self.last_fast_time = None
                self.last_fast_speed = None
                new_launch = True
        elif self.last_fast_time is not None and seconds - self.last_fast_time <= 6.0:
            # Reacquisition after motion blur must happen on the fixed outer
            # bowl. Rotor digits form coherent inner tracks but are not the
            # ball that established the earlier fast trajectory.
            if self.descent_started is None:
                outer = [item for item in fitted if item[1].points[-1][4] >= 0.70]
                if outer:
                    fitted = outer
        if not fitted:
            self.points.clear()
            if self.ball_motion is not None:
                motion_time, motion_angle, motion_omega, motion_alpha, motion_radius = (
                    self.ball_motion
                )
                age = seconds - motion_time
                reliable_age = (
                    seconds - self.last_fast_time
                    if self.last_fast_time is not None
                    else float("inf")
                )
            else:
                age = float("inf")
                reliable_age = float("inf")
            prediction_window = 1.9
            landing_age = (
                seconds - self.landing_last_time
                if self.landing_last_time is not None
                else float("inf")
            )
            continuity_age = min(reliable_age, landing_age)
            if 0 < age <= prediction_window and continuity_age <= 2.4:
                # Continue the established trajectory briefly through blur or
                # compression.  Matching against the last fixed position made
                # the old tracker jump to whichever rotor digit arrived there.
                acceleration = max(-18.0, min(18.0, motion_alpha))
                predicted_angle = (
                    motion_angle
                    + motion_omega * age
                    + 0.5 * acceleration * age * age
                )
                descent_gate = (
                    self.descent_started is not None
                    or (
                        self.ball_hypothesis is not None
                        and motion_radius <= 0.78
                        and self.last_fast_time is not None
                        and seconds - self.last_fast_time <= 2.2
                    )
                )
                minimum_radius = 0.46 if descent_gate else 0.70
                predicted_radius = motion_radius
                # The polynomial fit estimates angular motion well but v35
                # froze the radius during every missing frame.  Use the locked
                # hypothesis' polar filter to continue a measured inward
                # descent through separators and compression blur.
                if self.ball_hypothesis is not None:
                    filter_angle = float(self.ball_hypothesis.state[0, 0])
                    filter_omega = float(self.ball_hypothesis.state[1, 0])
                    filter_radius = float(self.ball_hypothesis.state[2, 0])
                    if (
                        math.isfinite(filter_angle)
                        and math.isfinite(filter_omega)
                        and math.isfinite(filter_radius)
                        and abs(filter_omega) <= 45
                    ):
                        predicted_angle = filter_angle
                        predicted_radius = filter_radius
                        if (
                            abs(filter_omega) >= 0.2
                            and math.copysign(1, filter_omega)
                            == math.copysign(1, motion_omega)
                        ):
                            motion_omega = filter_omega
                predicted_radius = max(
                    minimum_radius, min(0.98, predicted_radius)
                )
                tolerance = min(0.62, 0.16 + age * 1.25)
                nearby = [
                    candidate
                    for candidate in candidates
                    if candidate[3] >= minimum_radius
                    and self.angular_distance(candidate[2], predicted_angle)
                    <= tolerance
                    and abs(candidate[3] - predicted_radius)
                    <= (0.34 if descent_gate else 0.20)
                ]
                if nearby:
                    candidate = min(
                        nearby,
                        key=lambda item: (
                            self.angular_distance(item[2], predicted_angle)
                            + 1.6 * abs(item[3] - predicted_radius)
                            - 0.1 * item[4]
                        ),
                    )
                    x, y, angle, radius, quality = candidate
                    angle += (
                        round((predicted_angle - angle) / (2 * math.pi))
                        * 2
                        * math.pi
                    )
                    observed_omega = (angle - motion_angle) / age
                    if math.copysign(1, observed_omega) == math.copysign(
                        1, motion_omega
                    ):
                        motion_omega = 0.75 * motion_omega + 0.25 * observed_omega
                    self.ball_lock = (seconds, angle, x, y, radius)
                    if radius < 0.70 and self.descent_started is None:
                        self.descent_started = seconds
                    if radius < 0.70:
                        self.landing_last_time = seconds
                    self.ball_motion = (
                        seconds,
                        angle,
                        motion_omega,
                        acceleration,
                        radius,
                    )
                    return Track(
                        seconds,
                        (x, y),
                        angle,
                        confidence=max(
                            0.20, 0.48 * (1 - age / (prediction_window + 0.1))
                        ),
                        message=(
                            "Bille retrouvée près de la trajectoire prédite • "
                            "vitesse en attente de confirmation"
                        ),
                        radius=radius,
                        identity_locked=True,
                    )
                center_x, center_y, wheel_radius = self.wheel_geometry
                x = center_x + predicted_radius * wheel_radius * math.cos(
                    predicted_angle
                )
                y = center_y + predicted_radius * wheel_radius * math.sin(
                    predicted_angle
                )
                return Track(
                    seconds,
                    (x, y),
                    predicted_angle,
                    confidence=max(
                        0.15, 0.38 * (1 - age / (prediction_window + 0.1))
                    ),
                    message=(
                        "Bille prédite pendant une image floue • position non mesurée"
                    ),
                    radius=predicted_radius,
                    identity_locked=True,
                )
            growing = max(
                (item for item in self.hypotheses if item.misses == 0),
                key=lambda item: len(item.points),
                default=None,
            )
            if growing is None or not candidates:
                return Track(
                    seconds, message="Bille perdue ou reflets ambigus : aucune mesure"
                )
            point = growing.points[-1]
            return Track(
                seconds,
                (point[2], point[3]),
                point[1],
                message=(
                    f"Candidats lumineux : continuité {len(growing.points)}/7 • "
                    "identité non validée"
                ),
                radius=point[4],
            )

        def selection_score(item):
            confidence, hypothesis, fit_result = item
            score = confidence
            if self.ball_lock is not None and self.last_fast_time is not None:
                locked_angle = self.ball_lock[1]
                locked_radius = self.ball_lock[4]
                point = hypothesis.points[-1]
                score += 0.32 * max(
                    0.0,
                    1.0 - self.angular_distance(point[1], locked_angle) / 0.65,
                )
                score += 0.18 * max(0.0, 1.0 - abs(point[4] - locked_radius) / 0.28)
                if self.last_fast_speed is not None:
                    score += 0.12 * max(
                        0.0,
                        1.0 - abs(abs(fit_result[1]) - self.last_fast_speed)
                        / max(self.last_fast_speed, 0.5),
                    )
            return score

        confidence, selected, result = max(fitted, key=selection_score)
        self.points = deque(selected.points, maxlen=45)
        point = selected.points[-1]
        _, omega, alpha, residual = result
        previous_fast = self.last_fast_speed
        recently_fast = (
            self.last_fast_time is not None
            and seconds - self.last_fast_time <= 6.0
            and previous_fast is not None
        )
        settling = recently_fast and abs(omega) < max(0.75, previous_fast * 0.55)
        reliable_fast = (
            confidence >= 0.25
            and abs(omega) >= 1.0
        )
        if (
            not reliable_fast
            and confidence >= 0.18
            and abs(omega) >= 1.0
            and self.ball_motion is not None
            and self.last_fast_time is not None
            and seconds - self.last_fast_time <= 2.4
        ):
            motion_time, motion_angle, motion_omega, motion_alpha, _ = self.ball_motion
            age = max(0.0, seconds - motion_time)
            predicted_angle = motion_angle + motion_omega * age + 0.5 * max(
                -18.0, min(18.0, motion_alpha)
            ) * age * age
            reliable_fast = (
                math.copysign(1, omega) == math.copysign(1, motion_omega)
                and self.angular_distance(point[1], predicted_angle) <= 0.70
            )
        if reliable_fast:
            self.ball_lock = (seconds, point[1], point[2], point[3], point[4])
            self.ball_hypothesis = selected
            self.ball_motion = (seconds, point[1], omega, alpha, point[4])
            if point[4] < 0.70 and self.descent_started is None:
                self.descent_started = seconds
            if point[4] < 0.70:
                self.landing_last_time = seconds
        if settling:
            self.ball_lock = (seconds, point[1], point[2], point[3], point[4])
            self.ball_hypothesis = selected
            self.ball_motion = (seconds, point[1], omega, alpha, point[4])
            if point[4] < 0.70:
                if self.descent_started is None:
                    self.descent_started = seconds
                self.landing_last_time = seconds
            return Track(
                seconds,
                (point[2], point[3]),
                point[1],
                confidence=max(0.2, confidence),
                message=(
                    "Bille posée candidate : ralentissement après trajectoire mobile "
                    "• vitesse volontairement non publiée"
                ),
                radius=point[4],
                identity_locked=True,
            )
        if reliable_fast:
            self.last_fast_time = seconds
            self.last_fast_speed = abs(omega)
        return Track(
            seconds,
            (point[2], point[3]),
            point[1],
            omega,
            alpha,
            confidence,
            (
                "Trajectoire lumineuse cohérente • candidat bille non validé • "
                f"résidu {residual:.3f} rad"
            ),
            radius=point[4],
            identity_locked=self.ball_hypothesis is selected,
            new_launch=new_launch,
        )
