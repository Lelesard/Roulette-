# Livraison V40 — secteur dès 10 résultats

## Changement demandé

Le seuil d'affichage du premier secteur passe de 150 à 10 résultats. À dix
résultats, le tableau de bord affiche les 19 numéros et autorise leur horodatage
pour le prochain tour.

## Présentation honnête du résultat

Le secteur de 10 résultats est marqué **EXPLORATOIRE** dans l'interface. Le seuil
de 150 est conservé pour la validation chronologique stricte, avec échantillons
de sélection et de contrôle séparés. Cette distinction évite de présenter dix
observations comme une preuve statistique.

## Vérification

- test du seuil inférieur à 10 ;
- test de publication exploratoire à exactement 10 ;
- test de validation stricte à 150 ;
- test graphique du bouton et des deux libellés ;
- suite complète et archive extraite vérifiées avant publication.

Suite complète : **85 tests réussis**.
