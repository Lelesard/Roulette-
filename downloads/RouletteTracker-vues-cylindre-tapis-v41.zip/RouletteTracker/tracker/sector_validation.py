"""Chronological out-of-sample validation for one physical 19-number sector."""

from dataclasses import dataclass
import math

from .domain import WHEEL, number, sector


BASELINE_19 = 19 / 37
MINIMUM_EXPLORATORY = 10
MINIMUM_TRAIN = 90
MINIMUM_VALIDATION = 60


@dataclass(frozen=True)
class ValidatedSector19:
    center: int | None
    numbers: tuple
    train_size: int
    validation_size: int
    train_hits: int
    validation_hits: int
    train_rate: float | None
    validation_rate: float | None
    wilson_95: tuple | None
    p_value: float | None
    stable_halves: bool
    exploratory: bool
    reliable: bool
    message: str


def _wilson(successes, trials, z=1.959963984540054):
    if trials <= 0:
        return None
    rate = successes / trials
    denominator = 1 + z * z / trials
    center = (rate + z * z / (2 * trials)) / denominator
    half = (
        z
        * math.sqrt(rate * (1 - rate) / trials + z * z / (4 * trials * trials))
        / denominator
    )
    return max(0.0, center - half), min(1.0, center + half)


def _binomial_upper_tail(successes, trials, probability):
    if not 0 <= successes <= trials:
        raise ValueError("Comptage binomial invalide.")
    return min(
        1.0,
        sum(
            math.comb(trials, value)
            * probability**value
            * (1 - probability) ** (trials - value)
            for value in range(successes, trials + 1)
        ),
    )


def validate_sector19(results):
    values = [number(value) for value in results]
    required = MINIMUM_TRAIN + MINIMUM_VALIDATION
    if len(values) < MINIMUM_EXPLORATORY:
        return ValidatedSector19(
            None,
            (),
            min(len(values), MINIMUM_TRAIN),
            max(0, len(values) - MINIMUM_TRAIN),
            0,
            0,
            None,
            None,
            None,
            None,
            False,
            False,
            False,
            (
                "DONNÉES INSUFFISANTES — AUCUN SECTEUR FIABLE • "
                f"{len(values)}/{MINIMUM_EXPLORATORY} résultats requis pour une première analyse"
            ),
        )

    if len(values) < required:
        candidates = []
        for center in WHEEL:
            numbers = sector(center, 19)
            hits = sum(value in numbers for value in values)
            candidates.append((hits, center, numbers))
        hits, center, numbers = max(
            candidates, key=lambda item: (item[0], -WHEEL.index(item[1]))
        )
        rate = hits / len(values)
        return ValidatedSector19(
            center,
            numbers,
            len(values),
            0,
            hits,
            0,
            rate,
            None,
            None,
            None,
            False,
            True,
            False,
            (
                f"SECTEUR EXPLORATOIRE — {len(values)} résultats seulement • "
                f"centre {center} • présence historique {hits}/{len(values)} "
                f"({rate * 100:.1f} %) • validation statistique impossible avant {required} résultats"
            ),
        )

    # Freeze the selection on the oldest development/training portion.  Every
    # statistic used for acceptance comes from later, untouched observations.
    split = max(MINIMUM_TRAIN, round(len(values) * 0.60))
    split = min(split, len(values) - MINIMUM_VALIDATION)
    training = values[:split]
    validation = values[split:]
    candidates = []
    for center in WHEEL:
        numbers = sector(center, 19)
        hits = sum(value in numbers for value in training)
        candidates.append((hits, center, numbers))
    train_hits, center, numbers = max(
        candidates, key=lambda item: (item[0], -WHEEL.index(item[1]))
    )
    validation_hits = sum(value in numbers for value in validation)
    train_rate = train_hits / len(training)
    validation_rate = validation_hits / len(validation)
    interval = _wilson(validation_hits, len(validation))
    p_value = _binomial_upper_tail(
        validation_hits, len(validation), BASELINE_19
    )
    midpoint = len(validation) // 2
    blocks = (validation[:midpoint], validation[midpoint:])
    stable_halves = all(
        block and sum(value in numbers for value in block) / len(block) > BASELINE_19
        for block in blocks
    )
    reliable = bool(
        len(training) >= MINIMUM_TRAIN
        and len(validation) >= MINIMUM_VALIDATION
        and interval[0] > BASELINE_19
        and p_value < 0.05
        and stable_halves
    )
    if reliable:
        message = (
            f"Secteur 19 validé hors échantillon • centre {center} • "
            f"validation {validation_hits}/{len(validation)} "
            f"({validation_rate * 100:.1f} %) • p={p_value:.4f}"
        )
    else:
        message = (
            "DONNÉES INSUFFISANTES — AUCUN SECTEUR FIABLE • "
            f"candidat centre {center}, validation {validation_hits}/{len(validation)} "
            f"({validation_rate * 100:.1f} %), borne basse "
            f"{interval[0] * 100:.1f} %, p={p_value:.4f}"
        )
    return ValidatedSector19(
        center,
        numbers,
        len(training),
        len(validation),
        train_hits,
        validation_hits,
        train_rate,
        validation_rate,
        interval,
        p_value,
        stable_halves,
        False,
        reliable,
        message,
    )
