# Utilisation du secteur de 19 — V40

La page **Tableau de bord** utilise l'historique de la session.

- De 0 à 9 résultats : aucun secteur n'est affiché.
- Dès 10 résultats : un **SECTEUR EXPLORATOIRE** de 19 numéros apparaît.
- Le bouton permet de l'horodater avant le prochain tour. Le numéro suivant
  enregistre ensuite automatiquement une réussite ou un échec.
- À partir de 150 résultats : le programme sépare les données anciennes des
  données de validation. La mention **VALIDÉ HORS ÉCHANTILLON** n'apparaît que si
  tous les critères statistiques réussissent.

Un secteur obtenu avec 10 résultats est une première indication descriptive.
Les 150 résultats servent uniquement à distinguer cette indication d'une
validation statistique plus stricte.
