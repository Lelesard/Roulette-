# Rapport de tests V40

La V40 ajoute un scénario automatisé à exactement dix résultats. Il vérifie que
le moteur renvoie bien 19 numéros, que le secteur est marqué exploratoire et
qu'il n'est pas marqué fiable. Le test d'intégration graphique vérifie ensuite
que le bouton d'horodatage est disponible dès dix résultats, puis que le même
écran passe à la validation hors échantillon après 150 résultats concordants.

Résultat avant construction : **85 tests réussis** sous Linux avec Qt hors écran.
L'archive est ensuite extraite dans un dossier neuf et la même suite y est
relancée pour vérifier que les sources livrées correspondent aux sources testées.
