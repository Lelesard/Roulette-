import tempfile
import unittest
from pathlib import Path

from tracker.domain import WHEEL, sector
from tracker.sector_validation import (
    BASELINE_19,
    MINIMUM_EXPLORATORY,
    MINIMUM_TRAIN,
    MINIMUM_VALIDATION,
    validate_sector19,
)
from tracker.storage import Store


class Sector19ValidationTests(unittest.TestCase):
    def test_reference_and_sector_around_zero_are_exact(self):
        self.assertAlmostEqual(BASELINE_19, 19 / 37)
        self.assertEqual(
            sector(0, 19),
            (22, 18, 29, 7, 28, 12, 35, 3, 26, 0, 32, 15, 19, 4, 21, 2, 25, 17, 34),
        )

    def test_insufficient_data_never_publish_a_sector(self):
        report = validate_sector19([0] * (MINIMUM_EXPLORATORY - 1))
        self.assertFalse(report.reliable)
        self.assertEqual(report.numbers, ())
        self.assertIn("DONNÉES INSUFFISANTES", report.message)

    def test_ten_results_publish_an_explicitly_exploratory_sector(self):
        report = validate_sector19([0] * MINIMUM_EXPLORATORY)
        self.assertTrue(report.exploratory)
        self.assertFalse(report.reliable)
        self.assertEqual(report.center, 0)
        self.assertEqual(len(report.numbers), 19)
        self.assertIn("EXPLORATOIRE", report.message)

    def test_selection_and_validation_are_chronologically_separate(self):
        training = [0] * MINIMUM_TRAIN
        accepted = validate_sector19(training + [0] * MINIMUM_VALIDATION)
        self.assertTrue(accepted.reliable)
        self.assertEqual(accepted.center, 0)
        self.assertEqual(len(accepted.numbers), 19)
        outside = next(value for value in WHEEL if value not in accepted.numbers)
        rejected = validate_sector19(training + [outside] * MINIMUM_VALIDATION)
        self.assertFalse(rejected.reliable)
        self.assertEqual(rejected.center, accepted.center)
        self.assertLess(rejected.validation_rate, BASELINE_19)

    def test_balanced_history_does_not_create_a_reliable_sector(self):
        report = validate_sector19(list(WHEEL) * 5)
        self.assertFalse(report.reliable)
        self.assertIn("AUCUN SECTEUR FIABLE", report.message)

    def test_timestamped_prediction_is_evaluated_only_by_next_result(self):
        with tempfile.TemporaryDirectory() as tmp:
            store = Store(Path(tmp) / "tracker.sqlite3")
            sid = store.create_session("S", "Roulette A")
            for value in [0] * (MINIMUM_TRAIN + MINIMUM_VALIDATION):
                store.add_spin(sid, value)
            validation = validate_sector19(
                [row[0] for row in store.db.execute(
                    "SELECT number FROM spins WHERE session_id=? ORDER BY id", (sid,)
                )]
            )
            prediction_id = store.record_sector_prediction(
                sid,
                validation.center,
                validation.numbers,
                validation.train_size,
                validation.validation_size,
                "test",
            )
            pending = store.sector_predictions(sid)[0]
            self.assertEqual(pending["id"], prediction_id)
            self.assertEqual(pending["status"], "en attente")
            self.assertIsNone(pending["hit"])
            store.add_spin(sid, validation.numbers[0])
            evaluated = store.sector_predictions(sid)[0]
            self.assertEqual(evaluated["status"], "évaluée")
            self.assertEqual(evaluated["hit"], 1)
            store.close()


if __name__ == "__main__":
    unittest.main()
