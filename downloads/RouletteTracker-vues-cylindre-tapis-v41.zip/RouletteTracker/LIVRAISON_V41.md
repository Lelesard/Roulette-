# Livraison V41 — vues cylindre et tapis

Dans l'onglet **Racetrack**, le sélecteur **Disposition** permet de passer de
**Vue cylindre** à **Vue tapis**. La vue tapis reprend la disposition européenne :
zéro, 12 colonnes de trois numéros, douzaines et chances simples.

Les 37 boutons numérotés sont actifs. En mode saisie historique, un clic ajoute
immédiatement le résultat ; lorsque ce mode est désactivé, le clic choisit le
centre de la zone. Les couleurs, la zone cyan, le dernier résultat et les mises
déclarées sont synchronisés entre les deux vues. Le choix est conservé au
redémarrage.
