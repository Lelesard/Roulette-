@echo off
setlocal
cd /d "%~dp0"
if not exist .venv-windows\Scripts\python.exe (
    py -3.12 -m venv .venv-windows
    if errorlevel 1 py -3.11 -m venv .venv-windows
)
if not exist .venv-windows\Scripts\python.exe (
    echo Installez Python 3.11 ou 3.12 64 bits avec le lanceur py.
    pause
    exit /b 1
)
.venv-windows\Scripts\python.exe -m pip install -r requirements-tracker.txt || exit /b 1

set "TESSERACT_EXE=%ProgramFiles%\Tesseract-OCR\tesseract.exe"
if not exist "%TESSERACT_EXE%" if defined LOCALAPPDATA set "TESSERACT_EXE=%LOCALAPPDATA%\Programs\Tesseract-OCR\tesseract.exe"
if not exist "%TESSERACT_EXE%" (
    where winget >nul 2>nul
    if errorlevel 1 (
        echo ATTENTION : winget est absent, Tesseract OCR ne peut pas etre installe automatiquement.
    ) else (
        echo Installation automatique de Tesseract OCR...
        winget install --exact --id UB-Mannheim.TesseractOCR --silent --accept-package-agreements --accept-source-agreements
    )
)
set "TESSERACT_EXE=%ProgramFiles%\Tesseract-OCR\tesseract.exe"
if not exist "%TESSERACT_EXE%" if defined LOCALAPPDATA set "TESSERACT_EXE=%LOCALAPPDATA%\Programs\Tesseract-OCR\tesseract.exe"
if exist "%TESSERACT_EXE%" (
    echo Tesseract OCR detecte : %TESSERACT_EXE%
) else (
    echo ATTENTION : Tesseract OCR reste absent. Le Tracker fonctionnera sans lecture automatique des numeros.
)
echo Installation terminee. Lancez lancer_tracker.bat.
pause
