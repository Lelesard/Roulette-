# Historique en direct v16 — 5 novembre 2026

La table affiche une fine ligne de numéros en haut de la zone de jeu, au-dessus
de la roue. Cette ligne est la source à suivre. La grille de la fenêtre
Statistiques contient les 50 derniers tours et n'est pas adaptée à la détection
du prochain résultat.

Le calibrage agrandi indique explicitement cette ligne. Après sa sélection,
l'application enregistre deux lectures stables comme référence sans importer les
anciens numéros déjà affichés. Lorsqu'un nouveau numéro apparaît en tête de la
ligne, il doit être lu deux fois puis ajouté à l'historique et associé au lancer
mesuré si celui-ci est disponible.

La lecture agrandit l'image et remet les chiffres dans leur ordre horizontal.
Le sens de lecture reste configurable : sur cette table, il faut laisser coché
« Le résultat le plus récent est le premier dans le sens de lecture » si le
nouveau numéro apparaît à gauche.
