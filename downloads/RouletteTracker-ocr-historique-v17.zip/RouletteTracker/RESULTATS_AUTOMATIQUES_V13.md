# Résultats automatiques v13 — 5 novembre 2026

La v13 intègre l'installation du moteur OCR au parcours Windows. Le script
`installer_windows.bat` installe Tesseract avec Winget lorsqu'il n'est pas déjà
présent. L'application recherche automatiquement `tesseract.exe` dans le PATH,
Program Files et le dossier des programmes locaux de l'utilisateur. Le champ
manuel reste disponible pour une installation inhabituelle.

Les options d'analyse du panneau et d'ajout automatique sont maintenant
mémorisées. L'état OCR est également repris dans Diagnostics. Après deux lectures
stables, le recoupement ajoute uniquement le nouveau préfixe du panneau : une
image inchangée ne crée aucun doublon et une lecture ambiguë reste refusée.

Lorsqu'une seule nouvelle sortie est reconnue, son identifiant SQLite et son
numéro sont associés au dernier lancer mesuré sans résultat. L'import initial de
plusieurs anciens numéros reste dans l'historique mais n'est pas associé en bloc
aux mesures, car cette correspondance serait ambiguë. Aucune mise n'est réglée
par l'OCR.

La zone Résultats doit entourer au moins trois numéros du panneau historique,
sans le tapis, les montants ni le compte à rebours. La fiabilité sur cette table
Evolution doit être vérifiée sur le Legion Go après installation réelle de
Tesseract.
