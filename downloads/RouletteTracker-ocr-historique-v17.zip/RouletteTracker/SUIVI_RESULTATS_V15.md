# Suivi des résultats v15 — 5 novembre 2026

La première lecture OCR pouvait importer la rangée visible, mais les mises à
jour suivantes dépendaient d'un ordre gauche-droite choisi manuellement et d'un
recoupement parfait. Sur le panneau compact de la table rapide, un chiffre omis
empêchait donc l'ajout du nouveau résultat.

La v15 respecte le sens de lecture choisi, privilégie le recoupement exact et
accepte aussi un seul ancien chiffre manquant lorsque trois résultats au minimum
restent ordonnés. Les deux confirmations portent désormais sur le nouveau
préfixe : Tesseract peut varier sur un ancien chiffre sans recommencer tout le
cycle de stabilité. Une lecture ambiguë ne produit aucune écriture.

Paramètres et Diagnostics affichent désormais la rangée effectivement reconnue,
le mode de recoupement et les lectures ambiguës. Le calibrage agrandi v14,
l'installation de Tesseract et l'association d'une sortie unique au lancer
mesuré restent actifs.
