# OCR historique en direct v17

Cette version lit la fine bande horizontale des derniers numéros affichée en
haut du jeu. Elle ne lit ni la fenêtre « Statistiques », ni le tapis.

Après avoir cliqué sur **Calibrer l'historique en direct**, entourer seulement
les chiffres de cette bande. La première lecture stable devient une base : elle
ne remplit pas l'historique. Lorsqu'un nouveau numéro apparaît, deux lectures
identiques sont nécessaires avant l'ajout.

La lecture essaie une image normale, puis des images agrandies avec contraste et
seuillage. Les variantes de secours exigent quatre chiffres séparés et une
confiance minimale. Un texte fusionné, hors de 0 à 36, ou trop faible est rejeté
plutôt que deviné.
