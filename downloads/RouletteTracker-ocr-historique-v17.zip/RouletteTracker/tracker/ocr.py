"""Conservative OCR proposals, never derived from browser traffic."""

import shutil
import subprocess
import tempfile
import csv
import io
import os
from pathlib import Path

import cv2
from PySide6.QtCore import QObject, Signal, Slot


def reconcile(previous, current, min_overlap=3):
    """Newest-first lists. Return new prefix, or None if overlap is ambiguous.

    Identical snapshots do not create results. Repeated identical outcomes cannot
    be resolved from a static panel alone and are deliberately not inferred.
    """
    if len(current) < min_overlap:
        return None
    if not previous:
        return list(current)
    overlap = min(len(current), len(previous))
    if current[:overlap] == previous[:overlap] and overlap >= min_overlap:
        return []
    matches = []
    for added in range(1, len(current) - min_overlap + 1):
        length = min(len(previous), len(current) - added)
        if (
            length >= min_overlap
            and current[added : added + length] == previous[:length]
        ):
            matches.append(current[:added])
    return matches[0] if len(matches) == 1 else None


def _lcs_length(left, right):
    previous = [0] * (len(right) + 1)
    for a in left:
        current = [0]
        for index, b in enumerate(right, 1):
            current.append(
                previous[index - 1] + 1
                if a == b
                else max(previous[index], current[-1])
            )
        previous = current
    return previous[-1]


def _reconcile_tolerant(previous, current, min_overlap=3):
    exact = reconcile(previous, current, min_overlap)
    if exact is not None:
        return exact
    candidates = []
    for added in range(1, min(3, len(current) - min_overlap) + 1):
        tail = current[added:]
        expected = min(len(previous), len(tail))
        matches = _lcs_length(tail, previous)
        if matches >= min_overlap and matches >= expected - 1:
            candidates.append((matches, expected, -added, current[:added]))
    if not candidates:
        return None
    candidates.sort(reverse=True)
    return candidates[0][3]


def reconcile_panel(previous, current, min_overlap=3):
    """Reconcile a newest-first strip, tolerating one missing old token."""
    if not previous:
        return list(current), "initial"
    exact = reconcile(previous, current, min_overlap)
    if exact is not None:
        return exact, "exact"
    tolerant = _reconcile_tolerant(previous, current, min_overlap)
    if tolerant is None:
        return None, "ambigu"
    return tolerant, "tolérant"


def find_tesseract(executable=""):
    """Find a Windows or PATH installation without requiring manual setup."""
    candidates = []
    if executable and executable.strip():
        candidates.append(executable.strip().strip('"'))
    found = shutil.which("tesseract")
    if found:
        candidates.append(found)
    for variable in ("ProgramFiles", "PROGRAMFILES", "ProgramFiles(x86)"):
        root = os.environ.get(variable)
        if root:
            candidates.append(str(Path(root) / "Tesseract-OCR" / "tesseract.exe"))
    local = os.environ.get("LOCALAPPDATA")
    if local:
        candidates.append(
            str(Path(local) / "Programs" / "Tesseract-OCR" / "tesseract.exe")
        )
    for candidate in candidates:
        if Path(candidate).is_file():
            return str(Path(candidate))
    return None


def _read_variant(command, image, psm, minimum_confidence, minimum_count):
    """Read one image treatment and return its left-to-right tokens.

    A history strip contains tiny coloured digits.  Keeping each OCR treatment
    independent is important: a treatment that merges two digits is rejected,
    rather than being allowed to contaminate the stored history.
    """
    with tempfile.TemporaryDirectory(prefix="roulette-ocr-") as temp:
        path = Path(temp) / "history.png"
        if not cv2.imwrite(str(path), image):
            raise ValueError("Écriture temporaire OCR impossible.")
        result = subprocess.run(
            [
                command, str(path), "stdout", "--psm", str(psm), "-c",
                "tessedit_char_whitelist=0123456789 ", "tsv",
            ],
            capture_output=True, text=True, timeout=8,
            creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
        )
    if result.returncode:
        raise ValueError("Tesseract : " + result.stderr.strip()[-250:])
    tokens = []
    for row in csv.DictReader(io.StringIO(result.stdout), delimiter="\t"):
        text = row.get("text", "").strip()
        if not text:
            continue
        if (
            not text.isdigit() or len(text) > 2 or not 0 <= int(text) <= 36
            or (len(text) > 1 and text.startswith("0"))
        ):
            return None
        try:
            confidence = float(row["conf"]) / 100
        except (KeyError, ValueError):
            return None
        tokens.append((int(row["left"]), int(text), confidence))
    if len(tokens) < minimum_count or min(token[2] for token in tokens) < minimum_confidence:
        return None
    return [token[1] for token in sorted(tokens)]


def read_numbers(frame, executable="", newest_left=True):
    command = find_tesseract(executable)
    if not command:
        raise ValueError(
            "Tesseract absent. Relancez installer_windows.bat pour installer l’OCR."
        )
    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)

    # The first pass preserves the old, strict reading for a clean panel.  The
    # following passes are dedicated to the very small live strip: it is one
    # line, so enlargement, local contrast and thresholding are more useful
    # than the generic block layout used for the former statistics panel.
    basic = cv2.resize(gray, None, fx=3, fy=3, interpolation=cv2.INTER_CUBIC)
    basic = cv2.copyMakeBorder(basic, 12, 12, 12, 12, cv2.BORDER_CONSTANT, value=255)
    variants = [(basic, 6, 0.85, 3)]

    enlarged = cv2.resize(gray, None, fx=8, fy=8, interpolation=cv2.INTER_CUBIC)
    enhanced = cv2.createCLAHE(clipLimit=2.0, tileGridSize=(8, 8)).apply(enlarged)
    for candidate in (enlarged, enhanced):
        candidate = cv2.copyMakeBorder(candidate, 28, 28, 28, 28, cv2.BORDER_CONSTANT, value=255)
        variants.append((candidate, 7, 0.70, 4))
        _, binary = cv2.threshold(candidate, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)
        variants.append((binary, 7, 0.70, 4))
        variants.append((cv2.bitwise_not(binary), 7, 0.70, 4))

    for image, psm, confidence, count in variants:
        values = _read_variant(command, image, psm, confidence, count)
        if values is not None:
            return values if newest_left else values[::-1]
    raise ValueError(
        "OCR insuffisant : la ligne est trop petite ou mal cadrée. "
        "Cadrez seulement la bande de chiffres en haut du jeu."
    )


class OCRWorker(QObject):
    ready = Signal(object, object)  # context token, newest-first snapshot
    error = Signal(object, str)

    @Slot(object, object, str, bool)
    def read(self, context, frame, executable, newest_left):
        try:
            self.ready.emit(context, read_numbers(frame, executable, newest_left))
        except Exception as exc:
            self.error.emit(context, str(exc))
