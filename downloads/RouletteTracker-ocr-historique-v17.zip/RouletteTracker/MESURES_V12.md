# Séquences complètes v12 — 4 novembre 2026

La v12 corrige la découpe automatique des lancers enregistrés par la v11. Une
perte momentanée du candidat bille ne termine plus le lancer lorsque le rotor
est encore mesuré. La fin automatique exige maintenant simultanément cinq
secondes sans bille validée et trois secondes sans mesure du rotor. Un changement
de caméra ou de contexte, un arrêt de capture et le bouton de fin manuelle
continuent de fermer immédiatement la séquence.

Le fichier fourni depuis le Legion Go contenait trois lancers terminés et un
lancer actif. La bille des trois dernières séquences ralentissait dans le même
sens tandis que le rotor restait visible : il s'agissait vraisemblablement d'un
seul lancer découpé par les pertes de bille. Rejouées avec la v12, ces séquences
sont regroupées en une seule série active de 203 échantillons. Le premier lancer
reste séparé à cause d'un changement réel de contexte caméra.

L'enregistrement actif est sauvegardé environ chaque seconde dans
`%LOCALAPPDATA%\RouletteTracker\roulette-measurements-v12.json`. Diagnostics
permet de terminer manuellement la séquence et d'exporter
`roulette-mesures-v12.json`. Chaque échantillon contient les temps, la session,
l'époque caméra, les mesures et diagnostics de la bille et du rotor. Aucune
image, URL, titre de fenêtre ou identité de casino n'est enregistrée.

Validation : 42 tests sous Linux avec Qt hors écran, dont le retour d'une bille
après une perte plus longue que le délai bille pendant que le rotor continue.
La relecture du véritable export v11 valide également le regroupement attendu.
Ces mesures restent expérimentales et ne constituent pas une prédiction.
