# Calibrage agrandi v14 — 5 novembre 2026

La petite prévisualisation de Direct rendait la rangée des derniers résultats
difficile à sélectionner sur le Legion Go. Le bouton **Calibrer les résultats**
ouvre maintenant une fenêtre maximisée contenant une image figée à grande
échelle. Un glissement tactile ou à la souris enregistre la région et ferme la
fenêtre. Annuler laisse le calibrage précédent intact.

La sélection doit contenir toute la rangée des cases numérotées avec une petite
marge verticale. Elle ne doit pas inclure le titre du panneau, la roue graphique,
les montants ou le tapis complet. Le cadre reste enregistré en coordonnées
relatives et continue donc de suivre la taille de la capture.

La v14 conserve l'installation automatique de Tesseract, les options OCR
mémorisées, le recoupement sans doublon et l'association d'un nouveau numéro au
lancer mesuré. La qualité de lecture réelle dépend encore de la taille et du
contraste des chiffres diffusés par la table.
