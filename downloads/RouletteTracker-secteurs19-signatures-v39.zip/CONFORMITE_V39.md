# Conformité RouletteTracker V39 — 7 novembre 2026

## Objectif central

La V39 construit les 37 secteurs physiques de 19 numéros selon l'ordre européen
simple zéro. Elle utilise exactement neuf voisins à gauche, le centre et neuf
voisins à droite. La référence affichée est `19/37`, soit environ 51,35 %.

## Décision hors échantillon

Le moteur `tracker/sector_validation.py` applique une séparation chronologique :

1. au moins 90 résultats anciens servent à sélectionner un seul centre parmi les
   37 secteurs chevauchants ;
2. au moins 60 résultats ultérieurs restent hors sélection ;
3. l'acceptation exige une borne basse de Wilson à 95 % supérieure à 19/37 ;
4. le test binomial unilatéral doit donner `p < 0,05` ;
5. chacune des deux moitiés de validation doit dépasser la référence.

Si une condition échoue, le tableau de bord affiche :

**DONNÉES INSUFFISANTES — AUCUN SECTEUR FIABLE**

Le candidat de développement reste masqué. Lorsqu'un secteur est accepté,
l'utilisateur peut l'horodater pour le prochain tour. La table SQLite
`sector_predictions` conserve les 19 numéros, la méthode, la fin des données
d'apprentissage et le résultat obtenu ensuite.

## Tableau de conformité

| Exigence V39 | État | Preuve ou limite |
|---|---|---|
| Ordre européen exact | Fonctionnel et testé | `domain.py`, tests autour du zéro |
| 37 secteurs 9+1+9 | Fonctionnel et testé | `sector_validation.py`, `methods.py` |
| Référence 19/37 | Fonctionnel et testé | constante `BASELINE_19` |
| Fenêtres 10/20/50/100/session | Fonctionnel et testé | méthode modulaire `SlidingWindows` |
| Secteurs chevauchants | Fonctionnel et testé | les 37 sont comparés ; avertissement visible |
| Séries et répétitions | Fonctionnel et testé | méthode `Repetitions` |
| Validation chronologique séparée | Fonctionnel et testé | 90 apprentissage + 60 validation minimum |
| Secteur masqué si validation échoue | Fonctionnel et testé | moteur et test du tableau de bord |
| Prédiction horodatée avant résultat | Fonctionnel et testé | `sector_predictions`, évaluation au tour suivant |
| Zones / bille / rotor séparés | Partiellement fonctionnel | champs distincts dans le JSON de mesures ; migration vers des tables SQLite dédiées restante, qualité réelle expérimentale |
| Profils croupier/lanceur | Fonctionnel et testé | SQLite et page Signature, sans biométrie |
| Calibrage centre/rayon/perspective | Partiellement fonctionnel | ROI rectangulaire, centre/rayon persistants ; zéro manuel restant |
| Historique et OCR | Partiellement fonctionnel | anti-doublon testé ; dépend de Tesseract et du cadrage réel |
| Bankroll locale | Fonctionnel et testé | centimes entiers, paiements européens, aucune mise externe |
| Migration V37/V38 | Fonctionnel et testé | migrations additives `dealer_id` et nouvelles tables |
| Validation vidéo réelle annotée | Non implémentée faute de données | aucun taux de précision réel annoncé |
| Construction Windows | À vérifier sur Windows | tests Linux/Qt hors écran uniquement |

## Limite statistique essentielle

Une validation historique favorable ne démontre pas que la relation se poursuivra.
Consulter plusieurs méthodes ou répéter la validation peut augmenter le risque de
faux positif. La preuve la plus forte reste une série de secteurs horodatés avant
les résultats futurs, conservant aussi les échecs.
