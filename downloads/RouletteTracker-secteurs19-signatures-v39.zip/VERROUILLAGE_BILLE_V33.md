# Verrouillage bille v33 — 6 novembre 2026

La vidéo du Tracker fournie après la v32 montre que le cercle jaune suivait
principalement les chiffres blancs du rotor, puis parfois le texte placé au-dessus
de la roue. La cause était double : la bande intérieure restait admise après une
première trajectoire et l'interface affichait certains candidats lumineux avant
leur validation.

## Correction

- Le suivi mobile reste dans l'anneau extérieur du cylindre. Les chiffres et les
  poches du rotor sont exclus de cette étape.
- Un candidat en cours de constitution n'est plus dessiné dans l'aperçu.
- Après une trajectoire mesurée, la position est prédite pendant au maximum une
  seconde lorsque la bille est floue. Cette position apparaît en orange discontinu
  et ne produit ni vitesse enregistrée ni prédiction de secteur.
- La reprise recherche un point extérieur près de la position attendue. Elle ne
  compare plus les nouveaux points à l'ancienne position immobile, mécanisme qui
  sélectionnait le chiffre du rotor arrivant au même endroit.
- Une position prédite expire même si elle croise d'autres reflets ; seule une
  nouvelle trajectoire mesurée peut prolonger le verrouillage.

## Validation

Les tests couvrent désormais les chiffres intérieurs en rotation, la disparition
brève de la bille, l'expiration de la prédiction et le masquage des candidats bruts
dans l'interface. Les deux vidéos sources sans incrustation du Tracker restent les
références de mesure. La troisième vidéo contient déjà les anciens cercles jaunes
dans ses pixels et sert uniquement à confirmer le défaut visuel de la v32.
