# Utilisation V38

## Profils de croupiers

Choisissez un profil dans la barre supérieure. Le bouton **+ Croupier** crée un
pseudonyme local et l'associe à la session. Aucune reconnaissance faciale ou
identification automatique n'est utilisée.

La page **Signature du croupier** distingue le nombre total de lancers du nombre
de lancers exploitables. Un lancer exige des observations de mouvement extérieur,
du rotor, une durée et un résultat confirmé. Une valeur absente reste absente.

## Observation vidéo

Activez **Signature par zones** dans Direct. L'interface présente séparément :

- le mouvement lumineux agrégé dans la couronne extérieure ;
- le candidat bille expérimental ;
- le rotor et son éventuel repère zéro.

Une zone colorée n'est pas une position certaine de bille. Une position prédite
pendant une occultation reste signalée comme prédite.

## Méthodes

La page **Méthodes** permet d'activer les analyses descriptives intégrées. Les
fenêtres glissantes, voisins, secteurs de 19 et répétitions portent uniquement sur
l'historique de la session. Elles ne prédisent pas le prochain lancer.

## Données

La base SQLite de l'utilisateur est migrée de manière additive. Les sessions,
résultats et opérations existants sont conservés. Sauvegardez la base depuis
Diagnostics avant une mise à jour importante.
