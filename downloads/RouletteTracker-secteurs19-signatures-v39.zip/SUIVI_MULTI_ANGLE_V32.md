# Suivi multi-angle v32 — 6 novembre 2026

Cette version a été contrôlée sur les deux enregistrements complets fournis. Le
premier contient deux lancements avec une grande roue ; le second montre deux
tours avec une roue plus petite et davantage d'interface autour.

## Corrections

- La zone admissible de la piste extérieure suit la déformation apparente de la
  roue. La bille ne disparaît plus automatiquement à chaque quart de tour.
- Une hypothèse de bille supprimée après plusieurs images floues libère bien son
  identité. Le suivi peut donc retrouver la même bille plus loin sur la piste.
- Un lancer exige trois mesures successives concordantes. Les animations très
  brèves des jetons et de la carte résultat ne créent plus un tour.
- Une perte temporaire inférieure à douze secondes reste rattachée au même
  lancement. Une trajectoire confirmée après une pause plus longue démarre un
  nouveau lancement même lorsque la roue continue de tourner.

## Vérification

Les 61 tests automatisés passent. Deux tests couvrent maintenant la variation de
rayon causée par la perspective et la reprise après perte d'identité. Sur les
deux vidéos réelles, l'analyse hors ligne sépare deux lancements dans chaque
enregistrement. Le premier angle fournit respectivement 44 et 76 mesures bille ;
le second fournit 12 et 31 mesures.

Le point suivi reste une mesure expérimentale. Ces vidéos améliorent la base de
validation, mais elles ne suffisent pas à garantir une prédiction de secteur sur
toutes les tables et tous les éclairages.
