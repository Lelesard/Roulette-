# Rapport d'exécution des tests V38 — 6 novembre 2026

## Exécution automatisée

Commande :

```bash
QT_QPA_PLATFORM=offscreen python -m unittest discover -s tests_tracker
```

Résultat obtenu : **78 tests exécutés, 78 réussis**.

| Groupe | Scénario | Résultat attendu | Résultat obtenu | Statut |
|---|---|---|---|---|
| Domaine | Ordre européen, secteurs symétriques et voisins gauche/droite | Numéros physiques exacts, sans doublon | Conforme | Réussi |
| Finances | Plein, chances simples, douzaines, colonnes et zéro | Paiements européens en centimes entiers | Conforme | Réussi |
| Migration | Ouverture d'une base V37 sans `dealer_id` | Session conservée et colonne ajoutée | Conforme | Réussi |
| Croupiers | Création et association à une session | Profil rechargé depuis SQLite | Conforme | Réussi |
| Historique | Ajout, correction, annulation, suppression, import/export | Transactions atomiques et sessions isolées | Conforme | Réussi |
| OCR | Carte résultat, répétition et réarmement | Un seul ajout par apparition | Conforme sur images synthétiques/Tesseract généré | Réussi |
| Capture | Thread MSS simulé, arrêt/reprise et gel interface | Images récentes, ressources dans le bon thread | Conforme sur bureau simulé | Réussi |
| Scène | Stabilité, occultation et changement de caméra | Cadre temporaire puis invalidation | Conforme | Réussi |
| Bille | Candidats, reflets, perte, descente, atterrissage | États distincts et prédictions signalées | Conforme sur séquences synthétiques | Réussi |
| Zones | Mouvement extérieur dans les deux sens avec rotor intérieur | Zone et sens sans publier un point de bille | Conforme sur synthèse | Réussi |
| Rotor | Rotation dans les deux sens et zéro vert | Mesure indépendante et rejet des images vides | Conforme sur synthèse | Réussi |
| Mesures | Séparation bille/zone/rotor/croupier | Champs distincts, aucune valeur inventée | Conforme | Réussi |
| Signature | Lancer complet et données manquantes | Exploitable seulement si tous les champs requis existent | Conforme | Réussi |
| Méthodes | Fenêtres, voisins, secteurs 19 et répétitions | Statistiques descriptives et limites affichées | Conforme | Réussi |
| Interface | Threads, onglets, persistance et smoke test | UI réactive hors écran | Conforme sous Linux/Qt hors écran | Réussi |

## Non-régression sur deux vidéos propres

Ces exécutions vérifient que les limites de séquences détectées n'ont pas changé.
Elles ne mesurent pas une précision de localisation, car aucune position de vérité
terrain image par image n'est fournie.

- Vidéo `131919 (1)` : deux séquences, plages de mesures 1,53–6,47 s et
  37,47–51,67 s.
- Vidéo `132714 (2)` : trois séquences, plages de mesures 2,93–3,67 s,
  14,87–24,73 s et 30,80–41,87 s.

## Limites de validation

- Aucun test Windows 10/11 réel n'a été exécuté dans cet environnement Linux.
- Aucun corpus vidéo indépendant avec positions de bille et angles rotor annotés
  n'a été fourni ; aucun taux réel de détection ou de faux positif n'est annoncé.
- Les vidéos filmant l'écran du Tracker contiennent déjà ses marqueurs et ne sont
  pas des sources indépendantes pour évaluer l'algorithme.
- Aucune capacité prédictive ou rentabilité n'est démontrée par ces tests.
