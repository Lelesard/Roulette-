# Signature par zones v37 — 6 novembre 2026

Cette version ne publie plus un point censé représenter la position exacte de la
bille. La piste extérieure fixe est divisée en douze zones. Le mouvement lumineux
actuel est agrégé par zone et le sens n'est affiché qu'après trois transitions
concordantes.

La bande intérieure du rotor est exclue du calcul afin que les chiffres et les
poches ne soient pas interprétés comme une bille. Le Tracker affiche la zone
extérieure courante, le sens horaire ou antihoraire observé à l'écran, une vitesse
angulaire approximative et une confiance. Le rotor conserve sa mesure séparée.

Le mode se nomme **Signature par zones** dans Direct et reste désactivé par défaut.
Il exige une zone de roue stable. Aucune position précise de bille ni prédiction
fiable n'est annoncée.

La suite contient 69 tests, dont un mouvement extérieur dans les deux sens avec
des détails de rotor tournant dans la bande intérieure. Sur une vidéo propre, des
zones sont reconnues sur 885 images analysées et un sens concordant sur 232 images.
