# Atterrissage et relance v35 — 6 novembre 2026

La v35 conserve l'identité de la bille après sa descente sur le plateau et pendant
sa rotation lente dans une poche. Cette phase ne peut commencer qu'après une
trajectoire extérieure puis une descente radialement cohérente. Les chiffres du
rotor ne peuvent donc pas initialiser seuls ce verrouillage.

Chaque observation intérieure confirmée rafraîchit le verrouillage local. Une
courte image manquante peut être traversée à partir de la dernière vitesse interne,
mais une bille réellement invisible finit toujours par effacer le point.

Sur une table rapide, une nouvelle trajectoire cohérente sur la piste extérieure
ferme explicitement le lancer précédent et ouvre le suivant. Le maintien dans une
poche ne doit ainsi pas fusionner deux parties successives.

La suite comprend 67 tests, dont une bille extérieure qui descend, ralentit pendant
plusieurs secondes au milieu de chiffres tournant en sens inverse, puis un nouveau
lancement extérieur. Les deux vidéos sources propres conservent leurs trajectoires
extérieures. Le nouvel angle fourni est une capture de l'aperçu avec les cercles
déjà dessinés ; il confirme visuellement la perte tardive mais ne permet pas de
recalculer indépendamment les pixels recouverts.
