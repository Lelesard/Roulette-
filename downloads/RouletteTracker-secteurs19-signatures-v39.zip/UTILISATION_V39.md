# Utilisation du secteur de 19 — V39

La page **Tableau de bord** analyse automatiquement l'historique chronologique de
la session.

- Avant 150 résultats, aucun secteur ne peut être publié.
- À partir de 150 résultats, les données anciennes choisissent un candidat et les
  données ultérieures servent uniquement à sa validation.
- Si les critères statistiques échouent, les 19 numéros restent masqués.
- Si les critères réussissent, le centre et les 19 numéros apparaissent.

Le bouton **Horodater ce secteur pour le prochain tour** enregistre la proposition
avant le résultat suivant. Ce résultat évalue ensuite automatiquement si le numéro
appartenait au secteur. Les échecs restent conservés.

Les pages **Méthodes** et **Signature du croupier** fournissent des analyses
descriptives supplémentaires. Elles ne remplacent pas la validation hors
échantillon du tableau de bord.
