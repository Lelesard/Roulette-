# Audit de conformité V37 → V38 — 6 novembre 2026

Cet audit décrit ce qui est démontré par le code et les tests. La présence d'une
classe n'est pas considérée comme une preuve de fonctionnement réel.

| Fonction | Fichier concerné | État | Problème constaté | Correction V38 |
|---|---|---|---|---|
| Capture de fenêtre Brave | `capture.py`, `live.py` | Partiellement fonctionnel | Testée avec un bureau simulé ; la capture Win32 réelle dépend de MSS et de la fenêtre visible | Journal, watchdog et threads conservés ; validation Windows réelle encore nécessaire |
| Import et lecture vidéo | `video.py`, `gui.py` | Fonctionnel et testé | Pas d'enregistrement vidéo de diagnostic intégré | Lecture, déplacement temporel et annotations conservés |
| Détection de la zone de roue | `capture.py`, `scene.py` | Expérimental | Hough/contours sensibles aux vues, reflets et changements de caméra | Confirmation sur plusieurs observations et invalidation lors d'une coupure conservées |
| Calibrage manuel | `live.py`, `widgets.py`, `storage.py` | Partiellement fonctionnel | Le zéro du rotor n'est pas encore sélectionnable manuellement | Rectangle persistant pour l'ellipse, centre et rayon internes éditables, profils rechargeables |
| Mouvement extérieur par 12 zones | `experimental.py` | Expérimental | La V37 enregistrait ce mouvement dans les champs de la bille | Champs, qualité, messages et stockage désormais séparés de la bille |
| Suivi candidat bille | `experimental.py` | Expérimental | Heuristiques lumineuses ; aucune vidéo de vérité terrain annotée fournie | Suivi multi-hypothèses et filtre polaire conservés, état explicitement expérimental |
| Évaluation du suivi bille | `benchmark.py` | Partiellement fonctionnel | Outil correct, mais aucun manifeste réel indépendant disponible dans l'archive | Refuse les jeux non marqués `validation` et les annotations absentes |
| Suivi du rotor | `experimental.py` | Expérimental | Corrélation polaire et zéro vert testés synthétiquement, pas validés sur un corpus annoté | Mesure indépendante de la bille et champs séparés conservés |
| Résultats OCR temporaires | `ocr.py`, `live.py` | Partiellement fonctionnel | Dépend de Tesseract et d'un calibrage précis ; qualité réelle variable | Anti-doublon transactionnel, réarmement après disparition et correction manuelle conservés |
| Historique manuel | `gui.py`, `storage.py` | Fonctionnel et testé | Aucun problème bloquant identifié | Clic Racetrack, annulation, correction, suppression confirmée, import/export conservés |
| Ordre physique européen | `domain.py` | Fonctionnel et testé | Aucun | Ordre simple zéro exact utilisé partout |
| Secteurs personnalisables | `domain.py`, `gui.py` | Fonctionnel et testé | Aucun problème bloquant identifié | Centre, voisins gauche/droite indépendants, préréglages 9/15/19 et analyse exhaustive des 37 secteurs de 19 |
| Méthodes historiques | `methods.py`, `gui.py` | Partiellement fonctionnel | Absentes en V37 | Registre modulaire, fenêtres 10/20/50/100/session, voisins, couverture 19 et répétitions ajoutés |
| Validation statistique | `evaluation.py`, `methods.py` | Partiellement fonctionnel | Pas de corpus validation réel fourni ; sélection multiple à signaler | Références théoriques, séparation validation et avertissements explicites |
| Modèle de secteur physique | `sector_model.py` | Expérimental | Requiert 12 tours labellisés et des angles fiables ; la V37 n'avait pas de validation indépendante | Ne publie rien sans concentration, vitesse compatible et mesures suffisantes |
| Profils de croupiers | `storage.py`, `gui.py` | Fonctionnel et testé | Absents en V37 | Table SQLite, migration, sélection par session et pseudonyme manuel ajoutés ; aucune biométrie |
| Signature du croupier | `signature.py`, `gui.py` | Partiellement fonctionnel | Une zone de mouvement seule n'est pas une signature | Agrège uniquement des lancers avec zone, rotor, durée et résultat réellement présents |
| Comparaison entre sessions | `signature.py`, `gui.py` | Partiellement fonctionnel | Graphiques et test statistique inter-session non terminés | Historique par profil et session visible ; distributions descriptives disponibles |
| Racetrack interactif | `widgets.py`, `gui.py` | Fonctionnel et testé | Interface historique ; sélection asymétrique non disponible | 37 numéros, voisins physiques, saisie rapide et synchronisation conservés |
| Bankroll et mises | `domain.py`, `storage.py`, `gui.py` | Fonctionnel et testé | Voisins comme type de règlement financier non implémentés | Plein, chances simples, douzaines, colonnes, zéro, corrections et annulations testés en centimes entiers |
| Stockage SQLite | `storage.py` | Fonctionnel et testé | Schéma sans version formelle en V37 | Migration additive `dealer_id` testée sans perte des sessions existantes |
| Mesures physiques JSON | `measurements.py` | Partiellement fonctionnel | Limite de 200 lancers ; stockage séparé de SQLite | Croupier et mouvement de zone distincts ajoutés, écritures atomiques conservées |
| Interface demandée en 8 onglets | `gui.py`, `live.py` | Partiellement fonctionnel | Organisation historique en 11 onglets | Pages Signature et Méthodes ajoutées ; refonte globale reportée pour éviter une régression fonctionnelle |
| Build Windows | `build_windows.bat`, workflow GitHub | Partiellement fonctionnel | Aucun EXE Windows construit dans l'environnement Linux | Scripts et smoke-test présents ; compilation/signature Windows à exécuter sur Windows |

## Modules inventoriés

- `capture.py` : Win32/MSS, régions et conversion Qt.
- `scene.py` : stabilité de scène et changement de caméra.
- `experimental.py` : zones, bille candidate, rotor et zéro vert.
- `measurements.py` : séquences physiques locales au format JSON.
- `ocr.py` : extraction de carte résultat, Tesseract et anti-doublon.
- `domain.py` : roue européenne, secteurs, attributs et paiements.
- `storage.py` : SQLite, sessions, résultats, finances, profils et croupiers.
- `methods.py` : méthodes descriptives modulaires.
- `signature.py` : caractéristiques observées par lancer et résumés de profils.
- `sector_model.py` : calibration empirique expérimentale de secteurs.
- `evaluation.py`, `benchmark.py` : évaluations hors ligne strictes.
- `video.py` : lecture vidéo asynchrone.
- `widgets.py`, `live.py`, `gui.py` : interface et orchestration Qt.
- `vision.py` : contrat minimal de détecteur ; `NoDetector` reste un point d'extension.

## Constantes heuristiques

Les seuils de luminosité, rayon, continuité, corrélation, Mahalanobis et coupure de
caméra dans `experimental.py`, `capture.py` et `scene.py` sont des paramètres
heuristiques. Les tests synthétiques vérifient leur cohérence logicielle, mais ils
ne les calibrent pas pour toutes les tables Evolution. Ils ne doivent pas être
présentés comme des probabilités ou des confiances statistiques.

## Fonctions restant expérimentales ou incomplètes

- suivi fiable de la bille sur vidéos réelles annotées ;
- suivi rotor validé sur vérité terrain ;
- sélection manuelle du zéro et vérification explicite du sens du rotor ;
- identification automatique d'un profil de caméra ;
- graphiques et tests inter-session pour les signatures ;
- méthodes personnalisées chargées depuis des fichiers externes ;
- mise financière « voisins » ;
- enregistrement facultatif des séquences de diagnostic ;
- construction et test du paquet sur un vrai Windows 10/11.

La V38 ne prétend donc pas satisfaire les critères qui nécessitent un corpus
annoté ou un environnement Windows réel absent de cette livraison.
