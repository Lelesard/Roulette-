# Secteurs par session v30 — 6 novembre 2026

Chaque table et chaque session possède désormais sa propre calibration de
secteurs. L'écran indique le nombre de tours exploitables sur douze et le nombre
de tours mesurés mais ignorés faute d'angles ou de confiance suffisants.

Un bouton **Effacer tout l'historique** est disponible dans Historique. Après une
confirmation explicite, il supprime tous les résultats de la session courante,
annule les règlements financiers qui leur sont liés, remet l'état OCR à zéro et
retire les mesures de cette session du calibrage. Les autres sessions restent
intactes et une entrée d'audit enregistre l'opération.

Le suivi de la poche zéro, la collecte physique et le modèle expérimental de la
v29 sont conservés. Aucun secteur n'est publié avant douze tours cohérents.
