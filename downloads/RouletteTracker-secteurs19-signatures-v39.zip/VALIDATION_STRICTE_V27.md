# Validation stricte v27 — 6 novembre 2026

L'analyse du journal, de la base SQLite et de l'export de mesures v26 a montré
que la capture Windows était stable, mais que le suivi validait des séquences
trop faibles. Sur 252 échantillons répartis en deux lancers, seulement onze
contenaient une vitesse de bille. Certaines directions avaient entre 5 % et 12 %
de confiance. Le même point encore visible après le résultat 18 avait aussi
ouvert un second lancer.

La v27 refuse désormais de publier une direction ou de verrouiller une bille en
dessous de 25 % de confiance. L'enregistreur exige trois mesures consécutives de
même sens avant d'ouvrir un lancer. Après l'association d'un résultat, il reste
bloqué jusqu'à une seconde complète sans bille suffisamment confiante; l'ancien
point ne peut donc plus devenir le lancer suivant.

Ces règles privilégient explicitement l'absence de mesure plutôt qu'une fausse
mesure. Le suivi demeure expérimental et ne produit aucune prédiction validée.
