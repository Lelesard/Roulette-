# Filtre polaire multi-hypothèses v36 — 6 novembre 2026

Cette version ajoute un filtre de Kalman polaire à chaque trajectoire candidate.
Son état contient l'angle déroulé, la vitesse angulaire, le rayon normalisé et la
vitesse radiale. Le temps réel entre les images alimente la prédiction et les
retards sont intégrés par étapes bornées.

Le filtre ne choisit jamais seul la bille. Le gestionnaire multi-hypothèses de la
v35 conserve la priorité d'identité, les limites géométriques et le verrouillage
extérieur. Une porte de Mahalanobis élimine seulement les mesures statistiquement
incompatibles. La covariance utilise la forme de Joseph et un bruit d'accélération
comportant les puissances de `dt` adaptées.

Lors d'une image manquante, la prédiction peut désormais prolonger simultanément
l'angle et la descente radiale. La position reste explicitement présentée comme
prédite et non comme une mesure réelle.

La suite comprend 68 tests. Un nouveau test vérifie les intervalles irréguliers,
le rejet d'un reflet éloigné et la stabilité de la covariance. Deux vidéos propres
conservent exactement les limites de séquences et plages de mesures obtenues avec
la v35. Les enregistrements filmant l'aperçu du Tracker ne permettent pas une
comparaison indépendante car ils contiennent déjà ses marqueurs.
