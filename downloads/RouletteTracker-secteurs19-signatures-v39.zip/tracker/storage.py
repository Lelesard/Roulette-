import csv
import json
import sqlite3
from datetime import datetime, timezone
from .domain import number, payout, attributes, WHEEL


def now():
    return datetime.now(timezone.utc).isoformat()


class Store:
    def __init__(self, path):
        self.db = sqlite3.connect(str(path))
        self.db.row_factory = sqlite3.Row
        self.db.executescript("""
        PRAGMA foreign_keys=ON;
        CREATE TABLE IF NOT EXISTS sessions(id INTEGER PRIMARY KEY, name TEXT NOT NULL, table_name TEXT NOT NULL, created TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS spins(id INTEGER PRIMARY KEY, session_id INTEGER NOT NULL REFERENCES sessions(id), number INTEGER NOT NULL CHECK(number BETWEEN 0 AND 36), created TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS operations(id INTEGER PRIMARY KEY, session_id INTEGER NOT NULL REFERENCES sessions(id), kind TEXT NOT NULL, amount INTEGER NOT NULL, stake INTEGER NOT NULL DEFAULT 0, gross INTEGER NOT NULL DEFAULT 0, spin_id INTEGER REFERENCES spins(id), note TEXT NOT NULL, created TEXT NOT NULL, voided INTEGER NOT NULL DEFAULT 0);
        CREATE TABLE IF NOT EXISTS audit(id INTEGER PRIMARY KEY, event TEXT NOT NULL, detail TEXT NOT NULL, created TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS settings(key TEXT PRIMARY KEY, value TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS annotations(id INTEGER PRIMARY KEY, video TEXT NOT NULL, seconds REAL NOT NULL, note TEXT NOT NULL, created TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS profiles(name TEXT PRIMARY KEY, config TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS ocr_state(session_id INTEGER PRIMARY KEY REFERENCES sessions(id), snapshot TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS dealers(id INTEGER PRIMARY KEY, name TEXT NOT NULL UNIQUE, notes TEXT NOT NULL DEFAULT '', created TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS sector_predictions(id INTEGER PRIMARY KEY, session_id INTEGER NOT NULL REFERENCES sessions(id), created TEXT NOT NULL, method TEXT NOT NULL, center INTEGER NOT NULL CHECK(center BETWEEN 0 AND 36), numbers TEXT NOT NULL, train_size INTEGER NOT NULL, validation_size INTEGER NOT NULL, training_end_spin_id INTEGER REFERENCES spins(id), status TEXT NOT NULL, outcome_spin_id INTEGER REFERENCES spins(id), hit INTEGER);
        CREATE INDEX IF NOT EXISTS spins_session ON spins(session_id,id);
        CREATE INDEX IF NOT EXISTS operations_session ON operations(session_id,id);
        """)
        columns = {
            row[1] for row in self.db.execute("PRAGMA table_info(sessions)")
        }
        if "dealer_id" not in columns:
            with self.db:
                self.db.execute(
                    "ALTER TABLE sessions ADD COLUMN dealer_id INTEGER REFERENCES dealers(id)"
                )
        with self.db:
            self.db.execute(
                "INSERT OR IGNORE INTO dealers(name,notes,created) VALUES(?,?,?)",
                ("Non renseigné", "Profil par défaut", now()),
            )
            self.db.execute(
                "UPDATE sessions SET dealer_id=(SELECT id FROM dealers WHERE name='Non renseigné') "
                "WHERE dealer_id IS NULL"
            )

    def close(self):
        self.db.close()

    def sessions(self):
        return self.db.execute("SELECT * FROM sessions ORDER BY id DESC").fetchall()

    def create_session(self, name, table):
        if not name.strip() or not table.strip():
            raise ValueError("Nom et table requis.")
        default_dealer = self.db.execute(
            "SELECT id FROM dealers WHERE name='Non renseigné'"
        ).fetchone()[0]
        with self.db:
            return self.db.execute(
                "INSERT INTO sessions(name,table_name,created,dealer_id) VALUES(?,?,?,?)",
                (name.strip(), table.strip(), now(), default_dealer),
            ).lastrowid

    def dealers(self):
        return self.db.execute(
            "SELECT d.*,COUNT(s.id) AS session_count "
            "FROM dealers d LEFT JOIN sessions s ON s.dealer_id=d.id "
            "GROUP BY d.id ORDER BY d.name"
        ).fetchall()

    def create_dealer(self, name, notes=""):
        cleaned = name.strip()
        if not cleaned:
            raise ValueError("Nom ou pseudonyme du croupier requis.")
        try:
            with self.db:
                return self.db.execute(
                    "INSERT INTO dealers(name,notes,created) VALUES(?,?,?)",
                    (cleaned, notes.strip(), now()),
                ).lastrowid
        except sqlite3.IntegrityError:
            raise ValueError("Ce profil de croupier existe déjà.") from None

    def assign_dealer(self, sid, dealer_id):
        dealer = self.db.execute(
            "SELECT id FROM dealers WHERE id=?", (dealer_id,)
        ).fetchone()
        if dealer is None:
            raise ValueError("Profil de croupier introuvable.")
        with self.db:
            self.db.execute(
                "UPDATE sessions SET dealer_id=? WHERE id=?", (dealer_id, sid)
            )

    def session_dealer(self, sid):
        return self.db.execute(
            "SELECT d.* FROM sessions s LEFT JOIN dealers d ON d.id=s.dealer_id "
            "WHERE s.id=?",
            (sid,),
        ).fetchone()

    def setting(self, key, default=None):
        row = self.db.execute(
            "SELECT value FROM settings WHERE key=?", (key,)
        ).fetchone()
        return json.loads(row[0]) if row else default

    def save_setting(self, key, value):
        with self.db:
            self.db.execute(
                "INSERT OR REPLACE INTO settings VALUES(?,?)", (key, json.dumps(value))
            )

    def spins(self, sid, limit=100, offset=0):
        return self.db.execute(
            "SELECT * FROM spins WHERE session_id=? ORDER BY id DESC LIMIT ? OFFSET ?",
            (sid, limit, offset),
        ).fetchall()

    def counts(self, sid):
        return dict(
            self.db.execute(
                "SELECT number,COUNT(*) FROM spins WHERE session_id=? GROUP BY number",
                (sid,),
            ).fetchall()
        )

    def add_spin(self, sid, n, bets=(), settle_pending=False):
        number(n)
        # Validate and calculate everything before starting the transaction.
        stake = sum(b["stake"] for b in bets)
        gross = sum(payout(b["kind"], b["target"], b["stake"], n) for b in bets)
        with self.db:
            spin = self.db.execute(
                "INSERT INTO spins(session_id,number,created) VALUES(?,?,?)",
                (sid, n, now()),
            ).lastrowid
            pending_predictions = self.db.execute(
                "SELECT id,numbers FROM sector_predictions "
                "WHERE session_id=? AND status='en attente'",
                (sid,),
            ).fetchall()
            for prediction in pending_predictions:
                predicted_numbers = json.loads(prediction["numbers"])
                self.db.execute(
                    "UPDATE sector_predictions SET status='évaluée',outcome_spin_id=?,hit=? WHERE id=?",
                    (spin, int(n in predicted_numbers), prediction["id"]),
                )
            if bets:
                self.db.execute(
                    "INSERT INTO operations(session_id,kind,amount,stake,gross,spin_id,note,created) VALUES(?,?,?,?,?,?,?,?)",
                    (
                        sid,
                        "tour",
                        gross - stake,
                        stake,
                        gross,
                        spin,
                        json.dumps(list(bets), ensure_ascii=False),
                        now(),
                    ),
                )
            if settle_pending:
                self.db.execute(
                    "INSERT OR REPLACE INTO settings VALUES(?,?)",
                    (f"pending_{sid}", "[]"),
                )
            return spin

    def record_sector_prediction(
        self, sid, center, numbers, train_size, validation_size, method
    ):
        number(center)
        values = tuple(numbers)
        if len(values) != 19 or len(set(values)) != 19:
            raise ValueError("Un secteur enregistré doit contenir 19 numéros distincts.")
        for value in values:
            number(value)
        latest = self.db.execute(
            "SELECT id FROM spins WHERE session_id=? ORDER BY id DESC LIMIT 1", (sid,)
        ).fetchone()
        if latest is None:
            raise ValueError("Aucun historique disponible pour horodater le secteur.")
        duplicate = self.db.execute(
            "SELECT id FROM sector_predictions WHERE session_id=? AND status='en attente' "
            "AND training_end_spin_id=?",
            (sid, latest["id"]),
        ).fetchone()
        if duplicate:
            return duplicate["id"]
        with self.db:
            return self.db.execute(
                "INSERT INTO sector_predictions(session_id,created,method,center,numbers,"
                "train_size,validation_size,training_end_spin_id,status) "
                "VALUES(?,?,?,?,?,?,?,?,?)",
                (
                    sid,
                    now(),
                    method,
                    center,
                    json.dumps(values),
                    int(train_size),
                    int(validation_size),
                    latest["id"],
                    "en attente",
                ),
            ).lastrowid

    def sector_predictions(self, sid):
        return self.db.execute(
            "SELECT * FROM sector_predictions WHERE session_id=? ORDER BY id DESC",
            (sid,),
        ).fetchall()

    def edit_spin(self, spin, n=None):
        with self.db:
            row = self.db.execute("SELECT * FROM spins WHERE id=?", (spin,)).fetchone()
            if not row:
                raise ValueError("Résultat introuvable.")
            if n is not None:
                number(n)
            op = self.db.execute(
                "SELECT * FROM operations WHERE spin_id=? AND voided=0", (spin,)
            ).fetchone()
            if op:
                if n is None:
                    self.db.execute(
                        "UPDATE operations SET voided=1 WHERE id=?", (op["id"],)
                    )
                else:
                    bets = json.loads(op["note"])
                    gross = sum(
                        payout(b["kind"], b["target"], b["stake"], n) for b in bets
                    )
                    self.db.execute(
                        "UPDATE operations SET gross=?,amount=? WHERE id=?",
                        (gross, gross - op["stake"], op["id"]),
                    )
            self.db.execute(
                "INSERT INTO audit(event,detail,created) VALUES(?,?,?)",
                (
                    "correction résultat",
                    json.dumps({"avant": dict(row), "après": n}),
                    now(),
                ),
            )
            if n is None:
                self.db.execute(
                    "UPDATE sector_predictions SET status='annulée',outcome_spin_id=NULL "
                    "WHERE outcome_spin_id=?",
                    (spin,),
                )
                self.db.execute(
                    "UPDATE sector_predictions SET status='annulée',training_end_spin_id=NULL "
                    "WHERE training_end_spin_id=?",
                    (spin,),
                )
                self.db.execute(
                    "UPDATE operations SET spin_id=NULL WHERE spin_id=?", (spin,)
                )
                self.db.execute("DELETE FROM spins WHERE id=?", (spin,))
            else:
                self.db.execute("UPDATE spins SET number=? WHERE id=?", (n, spin))
                for prediction in self.db.execute(
                    "SELECT id,numbers FROM sector_predictions WHERE outcome_spin_id=?",
                    (spin,),
                ).fetchall():
                    self.db.execute(
                        "UPDATE sector_predictions SET hit=? WHERE id=?",
                        (int(n in json.loads(prediction["numbers"])), prediction["id"]),
                    )

    def clear_session_history(self, sid):
        """Remove every result for one session and void linked settlements."""
        with self.db:
            count = self.db.execute(
                "SELECT COUNT(*) FROM spins WHERE session_id=?", (sid,)
            ).fetchone()[0]
            self.db.execute(
                "DELETE FROM sector_predictions WHERE session_id=?", (sid,)
            )
            self.db.execute(
                "UPDATE operations SET voided=1,spin_id=NULL "
                "WHERE session_id=? AND spin_id IS NOT NULL",
                (sid,),
            )
            self.db.execute("DELETE FROM spins WHERE session_id=?", (sid,))
            self.db.execute("DELETE FROM ocr_state WHERE session_id=?", (sid,))
            self.db.execute(
                "INSERT INTO audit(event,detail,created) VALUES(?,?,?)",
                (
                    "suppression historique session",
                    json.dumps(
                        {"session_id": int(sid), "résultats_supprimés": int(count)},
                        ensure_ascii=False,
                    ),
                    now(),
                ),
            )
            return int(count)

    def cash(self, sid, kind, amount, note=""):
        if (
            kind not in ("initial", "dépôt", "retrait", "ajustement")
            or isinstance(amount, bool)
            or not isinstance(amount, int)
            or amount == 0
        ):
            raise ValueError("Opération invalide.")
        if kind != "ajustement" and amount < 0:
            raise ValueError("Montant positif requis.")
        with self.db:
            if (
                kind == "initial"
                and self.db.execute(
                    "SELECT 1 FROM operations WHERE session_id=? AND kind='initial' AND voided=0",
                    (sid,),
                ).fetchone()
            ):
                raise ValueError("Capital initial déjà saisi.")
            self.db.execute(
                "INSERT INTO operations(session_id,kind,amount,note,created) VALUES(?,?,?,?,?)",
                (sid, kind, -amount if kind == "retrait" else amount, note, now()),
            )

    def void(self, opid):
        with self.db:
            row = self.db.execute(
                "SELECT * FROM operations WHERE id=?", (opid,)
            ).fetchone()
            if not row or row["voided"]:
                raise ValueError("Opération absente ou déjà annulée.")
            self.db.execute("UPDATE operations SET voided=1 WHERE id=?", (opid,))
            self.db.execute(
                "INSERT INTO audit(event,detail,created) VALUES(?,?,?)",
                ("annulation opération", json.dumps(dict(row)), now()),
            )

    def operations(self, sid):
        return self.db.execute(
            "SELECT * FROM operations WHERE session_id=? ORDER BY id", (sid,)
        ).fetchall()

    def summary(self, sid=None):
        sql = "SELECT COALESCE(SUM(amount),0),COALESCE(SUM(stake),0),COALESCE(SUM(gross),0), COALESCE(SUM(CASE WHEN kind='tour' AND amount<0 THEN -amount ELSE 0 END),0), COALESCE(SUM(CASE WHEN kind='tour' AND amount>0 THEN amount ELSE 0 END),0) FROM operations WHERE voided=0"
        row = self.db.execute(
            sql + (" AND session_id=?" if sid is not None else ""),
            (sid,) if sid is not None else (),
        ).fetchone()
        return {
            "balance": row[0],
            "stake": row[1],
            "gross": row[2],
            "net": row[2] - row[1],
            "roi": 100 * (row[2] - row[1]) / row[1] if row[1] else 0,
            "losses": row[3],
            "profits": row[4],
        }

    def streaks(self, sid):
        current = {}
        longest = {}
        previous = {}
        run = {}
        for row in self.db.execute(
            "SELECT number FROM spins WHERE session_id=? ORDER BY id", (sid,)
        ):
            for kind, value in attributes(row[0]).items():
                run[kind] = run.get(kind, 0) + 1 if previous.get(kind) == value else 1
                previous[kind] = value
                current[kind] = (value, run[kind])
                longest[kind] = max(longest.get(kind, 0), run[kind])
        return current, longest

    def export(self, sid, path):
        rows = [
            dict(r)
            for r in self.db.execute(
                "SELECT * FROM spins WHERE session_id=? ORDER BY id", (sid,)
            )
        ]
        for r in rows:
            r.update(attributes(r["number"]))
            r["position_cylindre"] = WHEEL.index(r["number"])
        with open(path, "w", encoding="utf-8", newline="") as f:
            if str(path).lower().endswith(".json"):
                json.dump(rows, f, ensure_ascii=False, indent=2)
            else:
                writer = csv.DictWriter(
                    f,
                    fieldnames=[
                        "id",
                        "session_id",
                        "number",
                        "created",
                        "couleur",
                        "parité",
                        "hauteur",
                        "douzaine",
                        "colonne",
                        "position_cylindre",
                    ],
                )
                writer.writeheader()
                writer.writerows(rows)

    def import_file(self, sid, path):
        with open(path, encoding="utf-8-sig", newline="") as f:
            rows = (
                json.load(f)
                if str(path).lower().endswith(".json")
                else list(csv.DictReader(f))
            )
        values = []
        if not isinstance(rows, list):
            raise ValueError("Le fichier doit contenir une liste de résultats.")
        for r in rows:
            if not isinstance(r, dict):
                raise ValueError("Chaque résultat doit être un objet.")
            v = r.get("number", r.get("numero", r.get("numéro")))
            if isinstance(v, bool) or (
                not isinstance(v, int)
                and (not isinstance(v, str) or not v.strip().isdigit())
            ):
                raise ValueError("Numéro importé invalide.")
            n = number(int(v))
            created = r.get("created") or now()
            try:
                stamp = datetime.fromisoformat(created)
                if stamp.tzinfo is None:
                    raise ValueError()
                created = stamp.astimezone(timezone.utc).isoformat()
            except (ValueError, TypeError):
                raise ValueError(
                    "Date invalide : utilisez ISO 8601 avec fuseau horaire."
                ) from None
            values.append((n, created))
        with self.db:
            self.db.executemany(
                "INSERT INTO spins(session_id,number,created) VALUES(?,?,?)",
                [(sid, n, created) for n, created in values],
            )
        return len(values)

    def annotate(self, video, seconds, note):
        if not note.strip():
            raise ValueError("Annotation vide.")
        with self.db:
            self.db.execute(
                "INSERT INTO annotations(video,seconds,note,created) VALUES(?,?,?,?)",
                (video, seconds, note, now()),
            )

    def profile(self, name):
        row = self.db.execute(
            "SELECT config FROM profiles WHERE name=?", (name,)
        ).fetchone()
        return json.loads(row[0]) if row else {}

    def save_profile(self, name, config):
        if not name.strip():
            raise ValueError("Nom du profil requis.")
        with self.db:
            self.db.execute(
                "INSERT OR REPLACE INTO profiles VALUES(?,?)",
                (name, json.dumps(config)),
            )

    def profile_names(self):
        return [
            r[0] for r in self.db.execute("SELECT name FROM profiles ORDER BY name")
        ]

    def ocr_snapshot(self, sid):
        row = self.db.execute(
            "SELECT snapshot FROM ocr_state WHERE session_id=?", (sid,)
        ).fetchone()
        return json.loads(row[0]) if row else None

    def reset_ocr_baseline(self, sid):
        """Keep the next stable OCR strip as a reference without importing it."""
        with self.db:
            self.db.execute(
                "INSERT OR REPLACE INTO ocr_state VALUES(?,?)", (sid, "[]")
            )

    def commit_ocr(self, sid, snapshot, newest):
        """Persist the overlap cursor and new results in the same transaction; no bets settled."""
        for n in (*snapshot, *newest):
            number(n)
        inserted = []
        with self.db:
            for n in reversed(newest):
                spin = self.db.execute(
                    "INSERT INTO spins(session_id,number,created) VALUES(?,?,?)",
                    (sid, n, now()),
                ).lastrowid
                inserted.append((spin, n))
            self.db.execute(
                "INSERT OR REPLACE INTO ocr_state VALUES(?,?)",
                (sid, json.dumps(snapshot)),
            )
        return inserted
