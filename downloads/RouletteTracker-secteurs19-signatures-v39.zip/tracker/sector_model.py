"""Empirical sector calibration from chronologically labelled physical runs."""

from dataclasses import dataclass
import math

import numpy as np

from .domain import WHEEL, sector


@dataclass(frozen=True)
class SectorEstimate:
    center: int
    numbers: tuple
    confidence: float
    calibration_runs: int
    size: int
    message: str


class SectorModel:
    MINIMUM_RUNS = 12

    def __init__(self, offsets=(), speeds=()):
        self.offsets = tuple(offsets)
        self.speeds = tuple(speeds)

    @classmethod
    def from_runs(cls, runs):
        offsets = []
        speeds = []
        for run in runs:
            result = run.get("result")
            if not isinstance(result, int) or not 0 <= result <= 36:
                continue
            eligible = [
                sample
                for sample in run.get("samples", [])
                if sample.get("ball_angle_rad") is not None
                and sample.get("rotor_zero_angle_rad") is not None
                and sample.get("ball_omega_rad_s") is not None
                and float(sample.get("ball_confidence", 0)) >= 0.25
            ]
            if not eligible:
                continue
            sample = eligible[-1]
            relative = float(sample["ball_angle_rad"]) - float(
                sample["rotor_zero_angle_rad"]
            )
            target = WHEEL.index(result) * 2 * math.pi / 37
            offsets.append((target - relative) % (2 * math.pi))
            speeds.append(abs(float(sample["ball_omega_rad_s"])))
        return cls(offsets, speeds)

    @property
    def calibration_runs(self):
        return len(self.offsets)

    def estimate(
        self,
        ball_angle,
        ball_omega,
        ball_confidence,
        rotor_angle,
        rotor_confidence,
    ):
        if self.calibration_runs < self.MINIMUM_RUNS:
            return None
        values = np.asarray(self.offsets, dtype=float)
        vector = np.mean(np.exp(1j * values))
        concentration = float(abs(vector))
        if concentration < 0.62:
            return None
        speeds = np.asarray(self.speeds, dtype=float)
        median_speed = float(np.median(speeds))
        spread = float(np.median(np.abs(speeds - median_speed)))
        tolerance = max(0.35, 2.5 * spread)
        if abs(abs(float(ball_omega)) - median_speed) > tolerance:
            return None
        confidence = (
            concentration
            * max(0.0, min(1.0, float(ball_confidence)))
            * max(0.0, min(1.0, float(rotor_confidence)))
        )
        if confidence < 0.20:
            return None
        offset = math.atan2(vector.imag, vector.real) % (2 * math.pi)
        relative = (float(ball_angle) - float(rotor_angle) + offset) % (
            2 * math.pi
        )
        index = round(relative * 37 / (2 * math.pi)) % 37
        center = WHEEL[index]
        size = 9 if confidence >= 0.75 else 15 if confidence >= 0.48 else 19
        numbers = sector(center, size)
        return SectorEstimate(
            center,
            numbers,
            confidence,
            self.calibration_runs,
            size,
            (
                f"Secteur expérimental {size} numéros centré sur {center} • "
                f"confiance {confidence * 100:.0f} % • "
                f"calibration {self.calibration_runs} tours"
            ),
        )
