"""Conservative OCR proposals, never derived from browser traffic."""

import shutil
import subprocess
import tempfile
import csv
import io
import os
from pathlib import Path

import cv2
import numpy as np
from PySide6.QtCore import QObject, Signal, Slot


def reconcile(previous, current, min_overlap=3):
    """Newest-first lists. Return new prefix, or None if overlap is ambiguous.

    Identical snapshots do not create results. Repeated identical outcomes cannot
    be resolved from a static panel alone and are deliberately not inferred.
    """
    if len(current) < min_overlap:
        return None
    if not previous:
        return list(current)
    overlap = min(len(current), len(previous))
    if current[:overlap] == previous[:overlap] and overlap >= min_overlap:
        return []
    matches = []
    for added in range(1, len(current) - min_overlap + 1):
        length = min(len(previous), len(current) - added)
        if (
            length >= min_overlap
            and current[added : added + length] == previous[:length]
        ):
            matches.append(current[:added])
    return matches[0] if len(matches) == 1 else None


def _lcs_length(left, right):
    previous = [0] * (len(right) + 1)
    for a in left:
        current = [0]
        for index, b in enumerate(right, 1):
            current.append(
                previous[index - 1] + 1
                if a == b
                else max(previous[index], current[-1])
            )
        previous = current
    return previous[-1]


def _reconcile_tolerant(previous, current, min_overlap=3):
    exact = reconcile(previous, current, min_overlap)
    if exact is not None:
        return exact
    candidates = []
    for added in range(1, min(3, len(current) - min_overlap) + 1):
        tail = current[added:]
        expected = min(len(previous), len(tail))
        matches = _lcs_length(tail, previous)
        if matches >= min_overlap and matches >= expected - 1:
            candidates.append((matches, expected, -added, current[:added]))
    if not candidates:
        return None
    candidates.sort(reverse=True)
    return candidates[0][3]


def reconcile_panel(previous, current, min_overlap=3):
    """Reconcile a newest-first strip, tolerating one missing old token."""
    if not previous:
        return list(current), "initial"
    exact = reconcile(previous, current, min_overlap)
    if exact is not None:
        return exact, "exact"
    tolerant = _reconcile_tolerant(previous, current, min_overlap)
    if tolerant is None:
        return None, "ambigu"
    return tolerant, "tolérant"


def find_tesseract(executable=""):
    """Find a Windows or PATH installation without requiring manual setup."""
    candidates = []
    if executable and executable.strip():
        candidates.append(executable.strip().strip('"'))
    found = shutil.which("tesseract")
    if found:
        candidates.append(found)
    for variable in ("ProgramFiles", "PROGRAMFILES", "ProgramFiles(x86)"):
        root = os.environ.get(variable)
        if root:
            candidates.append(str(Path(root) / "Tesseract-OCR" / "tesseract.exe"))
    local = os.environ.get("LOCALAPPDATA")
    if local:
        candidates.append(
            str(Path(local) / "Programs" / "Tesseract-OCR" / "tesseract.exe")
        )
    for candidate in candidates:
        if Path(candidate).is_file():
            return str(Path(candidate))
    return None


def _ordered_quad(points):
    points = points.astype("float32")
    ordered = points.copy()
    sums = points.sum(axis=1)
    differences = points[:, 0] - points[:, 1]
    ordered[0] = points[sums.argmin()]       # top left
    ordered[2] = points[sums.argmax()]       # bottom right
    ordered[1] = points[differences.argmax()]  # top right
    ordered[3] = points[differences.argmin()]  # bottom left
    return ordered


def _extract_result_card(frame):
    """Find the large yellow quadrilateral and return its borderless interior."""
    hsv = cv2.cvtColor(frame, cv2.COLOR_BGR2HSV)
    yellow = cv2.inRange(hsv, (15, 70, 120), (45, 255, 255))
    yellow = cv2.morphologyEx(
        yellow,
        cv2.MORPH_CLOSE,
        cv2.getStructuringElement(cv2.MORPH_RECT, (5, 5)),
    )
    frame_area = frame.shape[0] * frame.shape[1]
    candidates = []
    contours, _ = cv2.findContours(
        yellow, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE
    )
    for contour in contours:
        area = cv2.contourArea(contour)
        perimeter = cv2.arcLength(contour, True)
        polygon = cv2.approxPolyDP(contour, 0.03 * perimeter, True)
        x, y, width, height = cv2.boundingRect(contour)
        aspect = width / max(1, height)
        if (
            len(polygon) == 4
            and cv2.isContourConvex(polygon)
            and area >= max(600, frame_area * 0.05)
            and width >= 45
            and height >= 45
            and 0.65 <= aspect <= 1.55
        ):
            candidates.append((area, polygon.reshape(4, 2)))
    if not candidates:
        raise ValueError("Résultat temporaire absent.")
    points = _ordered_quad(max(candidates, key=lambda item: item[0])[1])
    top_left, top_right, bottom_right, bottom_left = points
    width = max(
        1,
        round(max(
            ((top_right - top_left) ** 2).sum() ** 0.5,
            ((bottom_right - bottom_left) ** 2).sum() ** 0.5,
        )),
    )
    height = max(
        1,
        round(max(
            ((bottom_left - top_left) ** 2).sum() ** 0.5,
            ((bottom_right - top_right) ** 2).sum() ** 0.5,
        )),
    )
    target = np.array(
        [[0, 0], [width - 1, 0], [width - 1, height - 1], [0, height - 1]],
        dtype="float32",
    )
    matrix = cv2.getPerspectiveTransform(points, target)
    card = cv2.warpPerspective(frame, matrix, (width, height))
    margin_x = max(2, round(width * 0.12))
    margin_y = max(2, round(height * 0.12))
    interior = card[margin_y : height - margin_y, margin_x : width - margin_x]
    if interior.size == 0:
        raise ValueError("Carte du résultat trop petite.")
    return interior


def _read_variant(command, image, psm, minimum_confidence, minimum_count):
    """Read one image treatment and return its left-to-right tokens.

    A history strip contains tiny coloured digits.  Keeping each OCR treatment
    independent is important: a treatment that merges two digits is rejected,
    rather than being allowed to contaminate the stored history.
    """
    with tempfile.TemporaryDirectory(prefix="roulette-ocr-") as temp:
        path = Path(temp) / "history.png"
        if not cv2.imwrite(str(path), image):
            raise ValueError("Écriture temporaire OCR impossible.")
        result = subprocess.run(
            [
                command, str(path), "stdout", "--psm", str(psm), "-c",
                "tessedit_char_whitelist=0123456789 ", "tsv",
            ],
            capture_output=True, text=True, timeout=8,
            creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
        )
    if result.returncode:
        raise ValueError("Tesseract : " + result.stderr.strip()[-250:])
    tokens = []
    for row in csv.DictReader(io.StringIO(result.stdout), delimiter="\t"):
        text = row.get("text", "").strip()
        if not text:
            continue
        if (
            not text.isdigit() or len(text) > 2 or not 0 <= int(text) <= 36
            or (len(text) > 1 and text.startswith("0"))
        ):
            return None
        try:
            confidence = float(row["conf"]) / 100
        except (KeyError, ValueError):
            return None
        tokens.append((int(row["left"]), int(text), confidence))
    if len(tokens) < minimum_count or min(token[2] for token in tokens) < minimum_confidence:
        return None
    return [token[1] for token in sorted(tokens)]


def read_numbers(frame, executable="", newest_left=True):
    """Read exactly one roulette result from a tightly calibrated box."""
    command = find_tesseract(executable)
    if not command:
        raise ValueError(
            "Tesseract absent. Relancez installer_windows.bat pour installer l’OCR."
        )
    card = _extract_result_card(frame)
    gray = cv2.cvtColor(card, cv2.COLOR_BGR2GRAY)

    # The calibrated region now contains one result only. Several treatments
    # cope with white, red or green digits on a dark casino background.
    basic = cv2.resize(gray, None, fx=3, fy=3, interpolation=cv2.INTER_CUBIC)
    basic = cv2.copyMakeBorder(basic, 12, 12, 12, 12, cv2.BORDER_CONSTANT, value=255)
    variants = [(card, 10, 0.55, 1), (basic, 10, 0.75, 1)]

    enlarged = cv2.resize(gray, None, fx=8, fy=8, interpolation=cv2.INTER_CUBIC)
    enhanced = cv2.createCLAHE(clipLimit=2.0, tileGridSize=(8, 8)).apply(enlarged)
    for candidate in (enlarged, enhanced):
        candidate = cv2.copyMakeBorder(candidate, 28, 28, 28, 28, cv2.BORDER_CONSTANT, value=255)
        variants.append((candidate, 10, 0.65, 1))
        _, binary = cv2.threshold(candidate, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)
        variants.append((binary, 10, 0.65, 1))
        variants.append((cv2.bitwise_not(binary), 10, 0.65, 1))

    # Results use white digits on red, black or green cards. This mask ignores
    # the coloured background and the yellow outline before OCR.
    card_hsv = cv2.cvtColor(card, cv2.COLOR_BGR2HSV)
    white = cv2.inRange(card_hsv, (0, 0, 145), (180, 105, 255))
    white = cv2.bitwise_not(white)
    white = cv2.resize(white, None, fx=6, fy=6, interpolation=cv2.INTER_NEAREST)
    white = cv2.copyMakeBorder(white, 24, 24, 24, 24, cv2.BORDER_CONSTANT, value=255)
    variants.insert(0, (white, 10, 0.55, 1))

    for image, psm, confidence, count in variants:
        values = _read_variant(command, image, psm, confidence, count)
        if values is not None and len(values) == 1:
            return values
    raise ValueError(
        "Carte présente mais numéro illisible."
    )


class OCRWorker(QObject):
    ready = Signal(object, object)  # context token, newest-first snapshot
    error = Signal(object, str)

    @Slot(object, object, str, bool)
    def read(self, context, frame, executable, newest_left):
        try:
            self.ready.emit(context, read_numbers(frame, executable, newest_left))
        except Exception as exc:
            self.error.emit(context, str(exc))
