"""Modular descriptive methods; none predicts the next roulette result."""

from collections import Counter
from dataclasses import dataclass
from typing import Protocol

from .domain import WHEEL, number, sector


@dataclass(frozen=True)
class MethodResult:
    key: str
    title: str
    sample_size: int
    rows: tuple
    limits: str


class AnalysisMethod(Protocol):
    key: str
    title: str

    def analyze(self, results: list[int]) -> MethodResult: ...


def _validated(results):
    return [number(value) for value in results]


class SlidingWindows:
    key = "sliding"
    title = "Fenêtres glissantes"

    def analyze(self, results):
        values = _validated(results)
        rows = []
        for size in (10, 20, 50, 100, len(values)):
            if size <= 0 or size > len(values):
                continue
            window = values[-size:]
            counts = Counter(window)
            maximum = max(counts.values())
            leaders = tuple(n for n in WHEEL if counts[n] == maximum)
            label = "session" if size == len(values) else str(size)
            rows.append((label, size, leaders, maximum, maximum / size))
        return MethodResult(
            self.key,
            self.title,
            len(values),
            tuple(rows),
            "Fréquences descriptives ; aucune indépendance ni avantage futur démontré.",
        )


class Coverage19:
    key = "coverage19"
    title = "37 secteurs physiques de 19 numéros"
    BASELINE = 19 / 37

    def analyze(self, results):
        values = _validated(results)
        rows = []
        for center in WHEEL:
            numbers = sector(center, 19)
            hits = sum(value in numbers for value in values)
            rate = hits / len(values) if values else None
            rows.append(
                (
                    center,
                    numbers,
                    hits,
                    rate,
                    (rate - self.BASELINE) if rate is not None else None,
                )
            )
        rows.sort(key=lambda row: (-row[2], WHEEL.index(row[0])))
        return MethodResult(
            self.key,
            self.title,
            len(values),
            tuple(rows),
            "Référence théorique 19/37 = 51,35 %. Les 37 secteurs se chevauchent ; comparer le meilleur crée un biais de sélection multiple.",
        )


class NeighborConcentration:
    key = "neighbors"
    title = "Concentrations autour des voisins"

    def analyze(self, results):
        values = _validated(results)
        rows = []
        for center in WHEEL:
            numbers = sector(center, 9)
            hits = sum(value in numbers for value in values)
            rows.append((center, numbers, hits, hits / len(values) if values else None))
        rows.sort(key=lambda row: (-row[2], WHEEL.index(row[0])))
        return MethodResult(
            self.key,
            self.title,
            len(values),
            tuple(rows),
            "Concentration historique sur des secteurs chevauchants, sans prédiction.",
        )


class Repetitions:
    key = "repetitions"
    title = "Séries et répétitions"

    def analyze(self, results):
        values = _validated(results)
        adjacent = sum(a == b for a, b in zip(values, values[1:]))
        longest = 0
        current = 0
        previous = None
        gaps = {n: [] for n in WHEEL}
        last = {}
        for index, value in enumerate(values):
            current = current + 1 if value == previous else 1
            longest = max(longest, current)
            previous = value
            if value in last:
                gaps[value].append(index - last[value])
            last[value] = index
        gap_rows = tuple(
            (n, len(gaps[n]), sum(gaps[n]) / len(gaps[n]))
            for n in WHEEL
            if gaps[n]
        )
        return MethodResult(
            self.key,
            self.title,
            len(values),
            (("répétitions adjacentes", adjacent), ("plus longue série", longest))
            + gap_rows,
            "Les séries et écarts passés ne changent pas la probabilité théorique du prochain lancer indépendant.",
        )


BUILTIN_METHODS = {
    method.key: method
    for method in (
        SlidingWindows(),
        Coverage19(),
        NeighborConcentration(),
        Repetitions(),
    )
}


def run_methods(results, enabled=None):
    keys = tuple(enabled) if enabled is not None else tuple(BUILTIN_METHODS)
    return [BUILTIN_METHODS[key].analyze(results) for key in keys if key in BUILTIN_METHODS]
