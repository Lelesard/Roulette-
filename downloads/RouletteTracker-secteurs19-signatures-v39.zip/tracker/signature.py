"""Descriptive dealer/session signatures built only from recorded observations."""

from collections import Counter
from dataclasses import dataclass
import math

import numpy as np

from .domain import WHEEL


@dataclass(frozen=True)
class RunSignature:
    sequence: int
    session_id: int
    result: int | None
    duration_seconds: float | None
    zone_direction: str | None
    zone_speed: float | None
    rotor_direction: str | None
    rotor_speed: float | None
    last_zone: int | None
    usable: bool
    missing: tuple


def _finite_values(samples, key, minimum_quality_key=None, minimum_quality=0.0):
    values = []
    for sample in samples:
        value = sample.get(key)
        if value is None or isinstance(value, bool):
            continue
        try:
            value = float(value)
        except (TypeError, ValueError):
            continue
        if not math.isfinite(value):
            continue
        if minimum_quality_key and float(sample.get(minimum_quality_key, 0)) < minimum_quality:
            continue
        values.append(value)
    return values


def _majority_direction(values):
    signs = [1 if value > 0 else -1 for value in values if abs(value) >= 0.01]
    if not signs:
        return None
    positive = signs.count(1)
    negative = signs.count(-1)
    if positive == negative:
        return None
    return "horaire à l’écran" if positive > negative else "antihoraire à l’écran"


def extract_run_signature(run):
    samples = list(run.get("samples", []))
    zone = _finite_values(samples, "zone_omega_rad_s", "zone_quality", 0.20)
    rotor = _finite_values(samples, "rotor_omega_rad_s", "rotor_confidence", 0.20)
    zones = [
        int(sample["outer_zone"])
        for sample in samples
        if isinstance(sample.get("outer_zone"), int)
        and 1 <= sample["outer_zone"] <= 12
    ]
    result = run.get("result")
    if not isinstance(result, int) or not 0 <= result <= 36:
        result = None
    duration = run.get("duration_seconds")
    duration = (
        float(duration)
        if isinstance(duration, (int, float)) and math.isfinite(duration) and duration >= 0
        else None
    )
    missing = []
    if len(zone) < 3:
        missing.append("mouvement extérieur")
    if len(rotor) < 3:
        missing.append("rotor")
    if result is None:
        missing.append("résultat confirmé")
    if duration is None:
        missing.append("durée")
    return RunSignature(
        int(run.get("sequence", 0)),
        int(run.get("session_id", -1)),
        result,
        duration,
        _majority_direction(zone),
        float(np.median(np.abs(zone))) if zone else None,
        _majority_direction(rotor),
        float(np.median(np.abs(rotor))) if rotor else None,
        zones[-1] if zones else None,
        not missing,
        tuple(missing),
    )


def summarize_runs(runs):
    features = [extract_run_signature(run) for run in runs]
    usable = [feature for feature in features if feature.usable]
    zone_speeds = [feature.zone_speed for feature in usable]
    rotor_speeds = [feature.rotor_speed for feature in usable]
    durations = [feature.duration_seconds for feature in usable]
    directions = Counter(feature.zone_direction for feature in usable)
    arrival_zones = Counter(feature.last_zone for feature in usable)

    def distribution(values):
        if not values:
            return {"median": None, "mad": None, "minimum": None, "maximum": None}
        data = np.asarray(values, dtype=float)
        median = float(np.median(data))
        return {
            "median": median,
            "mad": float(np.median(np.abs(data - median))),
            "minimum": float(np.min(data)),
            "maximum": float(np.max(data)),
        }

    return {
        "runs": len(features),
        "usable": len(usable),
        "zone_speed": distribution(zone_speeds),
        "rotor_speed": distribution(rotor_speeds),
        "duration": distribution(durations),
        "directions": dict(directions),
        "arrival_zones": dict(arrival_zones),
        "results": Counter(feature.result for feature in usable),
        "features": features,
        "warning": (
            "Analyse descriptive seulement. Une régularité historique ne démontre "
            "pas une capacité à prévoir le prochain résultat."
        ),
    }


def result_wheel_positions(summary):
    return {
        WHEEL.index(number): count
        for number, count in summary["results"].items()
        if number is not None
    }
