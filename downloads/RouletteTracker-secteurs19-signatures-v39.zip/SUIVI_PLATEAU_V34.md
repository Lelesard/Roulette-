# Suivi plateau v34 — 6 novembre 2026

Cette version prolonge le verrouillage de la bille depuis la piste extérieure
jusqu'au plateau. La bande intérieure reste fermée tant qu'une trajectoire
extérieure fiable n'a pas établi l'identité de la bille. Elle ne s'ouvre ensuite
que lorsque le rayon descend progressivement et près de l'angle prévu.

Les chiffres du rotor ne peuvent donc pas démarrer seuls un suivi intérieur. Le
passage sous 70 % du rayon exige une continuité angulaire serrée et une variation
radiale limitée. Sur le plateau, le point reste visible mais la vitesse de bille
n'est plus publiée lorsqu'elle ne peut plus être séparée proprement du rotor.

Une mesure perdue peut être prédite en orange jusqu'à 1,9 seconde. Les
observations retrouvées près de cette trajectoire prolongent brièvement le suivi,
avec une limite absolue après la dernière mesure fiable afin d'éviter qu'un reflet
conserve indéfiniment le verrouillage.

La suite comprend 65 tests, dont une descente synthétique au milieu de chiffres
lumineux tournant en sens inverse. Les deux enregistrements propres déjà fournis
conservent exactement leurs plages de mesures de la v33. Le nouvel enregistrement
est une capture de l'interface avec les anciens cercles déjà dessinés ; il sert à
localiser le défaut mais ne permet pas une mesure indépendante pixel par pixel.
