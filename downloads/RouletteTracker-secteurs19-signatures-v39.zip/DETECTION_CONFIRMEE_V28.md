# Détection confirmée v28 — 6 novembre 2026

La v27 pouvait afficher « non mesuré » pendant tout un tour car les données du
Legion Go ne conservaient le seuil de 25 % que pendant deux analyses successives.
La v28 exige donc deux confirmations concordantes au lieu de trois, sans réduire
le seuil de confiance ni réafficher les hypothèses faibles.

L'export de mesures contient maintenant `recent_rejected_samples`. Même si aucun
lancer n'est ouvert, les derniers candidats, leur confiance et les motifs de
rejet sont disponibles pour le diagnostic. Cela permet d'ajuster la détection à
partir de valeurs réelles sans rendre les faux reflets visibles.

La zone dynamique est normalisée à 440 × 440 pixels avant l'analyse. Le point
trouvé est ensuite remis à l'échelle dans l'aperçu complet. Cette étape aligne la
résolution du Direct, où la roue mesure environ 200 pixels, avec celle utilisée
pour valider l'algorithme sur la vidéo brute.

Le rotor utilise désormais le même centre et le même rayon détectés que la
bille. Auparavant il déroulait systématiquement le centre du rectangle, alors
que la roue est décalée dans le cadre Direct. Une direction rotor fiable reste
disponible au maximum 0,8 seconde à travers une image ambiguë. Sur la vidéo brute
rejouée avec le cadre automatique, cette correction fait passer la séquence utile
de zéro à seize mesures bille publiées.
