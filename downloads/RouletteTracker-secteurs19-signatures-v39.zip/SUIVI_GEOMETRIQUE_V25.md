# Suivi géométrique v25 — 6 novembre 2026

Cette version corrige le faux suivi observé sur la vidéo réelle fournie. Le
tracker détecte d'abord le cercle physique de la cuve et des repères fixes dans
la couronne extérieure. Les textes hors de la roue et le tapis ne peuvent plus
servir de candidats.

Le suivi fonctionne en deux phases. Une trajectoire doit commencer sur la piste
extérieure avec un mouvement visible. La zone des poches ne devient accessible
qu'après cette trajectoire rapide. L'identité de la trajectoire est ensuite
verrouillée et les sauts radiaux sont limités : un chiffre blanc ou un reflet du
rotor ne peut plus remplacer librement le point déjà suivi. Quand la bille
ralentit dans la couronne, sa position candidate reste affichée sans publier une
vitesse artificielle.

La lecture du résultat temporaire est aussi plus tolérante. Une image OCR
illisible entre deux lectures identiques ne remet plus la validation à zéro et
deux absences réelles de la carte sont nécessaires avant de réarmer le tour
suivant.

La suite complète contient 47 tests réussis et le démarrage Qt hors écran est
validé. Le suivi a également été rejoué image par image sur la vidéo réelle
fournie. Le point reste un candidat visuel expérimental : il ne constitue pas
une reconnaissance certifiée de la bille ni une prédiction de résultat.
