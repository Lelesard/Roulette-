import sqlite3
import tempfile
import unittest
from pathlib import Path

import numpy as np

from tracker.domain import WHEEL, custom_sector, sector
from tracker.experimental import Track, ball_observation_state
from tracker.measurements import MeasurementRecorder
from tracker.live import AnalysisWorker
from tracker.methods import Coverage19, SlidingWindows
from tracker.signature import extract_run_signature, summarize_runs
from tracker.storage import Store


class V38MigrationTests(unittest.TestCase):
    def test_existing_database_is_migrated_without_losing_sessions(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "legacy.sqlite3"
            db = sqlite3.connect(path)
            db.execute(
                "CREATE TABLE sessions(id INTEGER PRIMARY KEY,name TEXT NOT NULL,"
                "table_name TEXT NOT NULL,created TEXT NOT NULL)"
            )
            db.execute(
                "INSERT INTO sessions VALUES(1,'Ancienne session','Roulette A','2026-01-01T00:00:00+00:00')"
            )
            db.commit()
            db.close()

            store = Store(path)
            self.assertEqual(store.sessions()[0]["name"], "Ancienne session")
            columns = {row[1] for row in store.db.execute("PRAGMA table_info(sessions)")}
            self.assertIn("dealer_id", columns)
            dealer = store.create_dealer("Croupier test")
            store.assign_dealer(1, dealer)
            self.assertEqual(store.session_dealer(1)["name"], "Croupier test")
            store.close()

    def test_saved_center_and_radius_are_applied_to_analysis(self):
        worker = AnalysisWorker()
        frame = np.zeros((440, 440, 3), np.uint8)
        context = (0, 1, "video", "fixture", 0, 1, (0.45, 0.55, 0.40))
        worker.analyze(context, frame, 0.0)
        for actual, expected in zip(
            worker.tracker.wheel_geometry, (198.0, 242.0, 176.0)
        ):
            self.assertAlmostEqual(actual, expected)


class V38SignatureTests(unittest.TestCase):
    @staticmethod
    def fixture_run():
        samples = []
        for index in range(5):
            samples.append(
                {
                    "zone_omega_rad_s": 4.0 + index * 0.1,
                    "zone_quality": 0.7,
                    "rotor_omega_rad_s": -0.8,
                    "rotor_confidence": 0.8,
                    "outer_zone": index + 1,
                }
            )
        return {
            "sequence": 3,
            "session_id": 7,
            "result": 32,
            "duration_seconds": 8.5,
            "samples": samples,
        }

    def test_signature_requires_real_zone_rotor_result_and_duration(self):
        feature = extract_run_signature(self.fixture_run())
        self.assertTrue(feature.usable)
        self.assertEqual(feature.zone_direction, "horaire à l’écran")
        self.assertEqual(feature.rotor_direction, "antihoraire à l’écran")
        summary = summarize_runs([self.fixture_run()])
        self.assertEqual(summary["usable"], 1)
        self.assertIn("descriptive", summary["warning"])

    def test_measurement_keeps_zone_motion_separate_from_ball_tracking(self):
        with tempfile.TemporaryDirectory() as tmp:
            recorder = MeasurementRecorder(Path(tmp) / "measurements.json", start_confirmations=1)
            track = Track(
                1.0,
                angle=0.4,
                omega=2.0,
                confidence=0.8,
                message="bille observée",
                zone=4,
                zone_omega=-5.0,
                zone_confidence=0.7,
                zone_message="mouvement extérieur",
            )
            recorder.add((0, 1, "video", "fixture", 0, 9), track, 1.0)
            sample = recorder.payload()["active_run"]["samples"][-1]
            self.assertEqual(sample["ball_omega_rad_s"], 2.0)
            self.assertEqual(sample["zone_omega_rad_s"], -5.0)
            self.assertEqual(sample["dealer_id"], 9)

    def test_zone_signature_can_open_a_run_without_inventing_a_ball_measurement(self):
        with tempfile.TemporaryDirectory() as tmp:
            recorder = MeasurementRecorder(
                Path(tmp) / "measurements.json", start_confirmations=2
            )
            track = Track(
                1.0,
                message="aucune bille observée",
                zone=2,
                zone_omega=4.5,
                zone_confidence=0.8,
                zone_message="trois transitions concordantes",
            )
            context = (0, 1, "video", "fixture", 0, 3)
            recorder.add(context, track, 1.0)
            recorder.add(context, track, 1.1)
            self.assertIsNotNone(recorder.current)
            sample = recorder.payload()["active_run"]["samples"][-1]
            self.assertIsNone(sample["ball_omega_rad_s"])
            self.assertEqual(sample["zone_omega_rad_s"], 4.5)

    def test_ball_states_distinguish_measurement_prediction_and_interruption(self):
        self.assertEqual(ball_observation_state(Track(0.0)), "Recherche de la bille")
        candidate = Track(0.1, point=(1, 2), message="candidat lumineux")
        self.assertEqual(ball_observation_state(candidate), "Bille candidate")
        followed = Track(0.2, point=(2, 3), omega=2.0, confidence=0.8)
        self.assertEqual(ball_observation_state(followed), "Bille suivie")
        predicted = Track(
            0.3,
            point=(3, 4),
            identity_locked=True,
            message="Bille prédite pendant une image floue",
        )
        self.assertEqual(
            ball_observation_state(predicted), "Bille temporairement perdue"
        )
        interrupted = Track(0.4, message="Changement de caméra : suivi réinitialisé")
        self.assertEqual(ball_observation_state(interrupted), "Suivi interrompu")


class V38MethodTests(unittest.TestCase):
    def test_custom_sector_supports_independent_left_and_right_neighbors(self):
        selected = custom_sector(0, 2, 3)
        self.assertEqual(selected, (3, 26, 0, 32, 15, 19))
        self.assertEqual(len(custom_sector(0, 9, 9)), 19)

    def test_sector_19_uses_physical_wheel_and_theoretical_baseline(self):
        results = list(WHEEL[:19])
        report = Coverage19().analyze(results)
        center = WHEEL[9]
        row = next(row for row in report.rows if row[0] == center)
        self.assertEqual(row[1], sector(center, 19))
        self.assertEqual(row[2], 19)
        self.assertAlmostEqual(Coverage19.BASELINE, 19 / 37)
        self.assertIn("chevauchent", report.limits)

    def test_sliding_windows_never_use_more_results_than_available(self):
        report = SlidingWindows().analyze(list(range(10)))
        self.assertEqual({row[1] for row in report.rows}, {10})
        self.assertIn("aucun", report.limits)


if __name__ == "__main__":
    unittest.main()
