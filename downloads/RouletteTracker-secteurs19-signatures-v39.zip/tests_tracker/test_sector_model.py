import math
import unittest

from tracker.domain import WHEEL
from tracker.sector_model import SectorModel


class SectorModelTests(unittest.TestCase):
    @staticmethod
    def sample_run(result, relative, speed=1.6, confidence=0.8):
        return {
            "result": result,
            "samples": [
                {
                    "ball_angle_rad": relative + 0.7,
                    "rotor_zero_angle_rad": 0.7,
                    "ball_omega_rad_s": -speed,
                    "ball_confidence": confidence,
                }
            ],
        }

    def test_requires_twelve_labelled_physical_runs(self):
        runs = [self.sample_run(32, 0.3) for _ in range(11)]
        model = SectorModel.from_runs(runs)
        self.assertEqual(model.calibration_runs, 11)
        self.assertIsNone(model.estimate(1.0, -1.6, 0.9, 0.7, 0.9))

    def test_predicts_calibrated_sector_and_rejects_unknown_speed(self):
        target = WHEEL.index(32) * 2 * math.pi / 37
        offset = 0.9
        relative = target - offset
        runs = [self.sample_run(32, relative + (index % 3 - 1) * 0.01) for index in range(15)]
        model = SectorModel.from_runs(runs)
        prediction = model.estimate(
            ball_angle=1.2 + relative,
            ball_omega=-1.6,
            ball_confidence=0.9,
            rotor_angle=1.2,
            rotor_confidence=0.9,
        )
        self.assertIsNotNone(prediction)
        self.assertEqual(prediction.center, 32)
        self.assertIn(32, prediction.numbers)
        self.assertIsNone(
            model.estimate(1.2 + relative, -4.0, 0.9, 1.2, 0.9)
        )

    def test_rejects_incoherent_calibration(self):
        runs = [
            self.sample_run(WHEEL[round(index * 37 / 12) % 37], 0.0)
            for index in range(12)
        ]
        model = SectorModel.from_runs(runs)
        self.assertIsNone(model.estimate(1.0, -1.6, 0.9, 0.7, 0.9))


if __name__ == "__main__":
    unittest.main()
