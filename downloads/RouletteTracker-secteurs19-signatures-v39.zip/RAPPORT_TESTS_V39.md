# Rapport de tests V39 — 7 novembre 2026

Commande principale :

```bash
QT_QPA_PLATFORM=offscreen python -m unittest discover -s tests_tracker
```

Résultat : **84 tests exécutés, 84 réussis**.

## Nouveaux scénarios V39

| Scénario | Attendu | Obtenu | Statut |
|---|---|---|---|
| Secteur autour du zéro | 9 voisins + 0 + 9 voisins selon le cylindre | Liste exacte de 19 numéros | Réussi |
| Historique inférieur à 150 | Aucun secteur publié | Message de données insuffisantes | Réussi |
| Sélection et validation séparées | Même centre sélectionné, décisions différentes selon validation | Accepté sur validation concentrée, rejeté hors secteur | Réussi |
| Historique équilibré | Aucun faux secteur fiable | Rejeté | Réussi |
| Horodatage | Proposition en attente avant résultat | Stockée avec fin d'apprentissage | Réussi |
| Résultat suivant | Évalue uniquement la proposition antérieure | État `évaluée`, succès/échec enregistré | Réussi |
| Tableau de bord | N'affiche le secteur qu'après validation | Bouton désactivé ou activé selon le rapport | Réussi |

Les tests V38 sur stockage, capture simulée, OCR, zones, bille, rotor, signatures,
méthodes et bankroll restent inclus.

## Limites

- Aucun corpus vidéo indépendant annoté n'a été fourni.
- Aucun taux réel de suivi bille/rotor n'est annoncé.
- Aucun build Windows n'a été exécuté depuis cet environnement Linux.
- Les données artificiellement concentrées des tests vérifient les règles de
  décision, pas l'existence d'un avantage réel sur une roulette.
