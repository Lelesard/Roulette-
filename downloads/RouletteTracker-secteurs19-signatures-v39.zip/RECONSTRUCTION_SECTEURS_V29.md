# Reconstruction secteurs v29 — 6 novembre 2026

Cette version reconstruit le chemin de données autour de l'estimation de secteur.
La poche zéro verte est détectée dans la couronne du rotor et sert de référence
angulaire absolue. Sur la vidéo brute fournie, son contraste est environ vingt
fois supérieur au fond et sa vitesse reste mesurée sur 441 images sur 445.

La bille et le rotor utilisent le même centre géométrique. Une bille tournant en
sens opposé au rotor est reconnue comme indépendante sans exiger une vitesse cinq
fois supérieure. La séquence utile de la vidéo de contrôle produit dix-sept
mesures bille validées au lieu de zéro.

Chaque mesure stocke désormais l'angle de la bille et celui du zéro. Lorsqu'un
résultat est associé au lancer, il devient un exemple de calibration. Le modèle
attend douze tours exploitables, mesure la cohérence circulaire et vérifie que la
vitesse courante appartient à la plage apprise. Il affiche alors un secteur de
9, 15 ou 19 numéros selon la confiance. Sinon, il indique la progression de
calibration et ne publie aucun secteur.

Ce secteur reste expérimental. Il ne déclenche aucune mise et sa valeur réelle
doit être évaluée chronologiquement sur des tours futurs, distincts des tours de
calibration.
