# Livraison V38

## Principales corrections

- séparation stricte mouvement par zones / bille / rotor ;
- états explicites du suivi bille ;
- profils de croupiers locaux liés aux sessions ;
- migration SQLite additive sans perte des anciennes sessions ;
- page **Signature du croupier** avec qualité et valeurs absentes ;
- quatre méthodes descriptives activables ;
- secteurs personnalisables avec voisins gauche/droite ;
- centre et rayon de roue persistants dans les profils ;
- valeurs de jetons 0,10 €, 0,20 €, 0,50 €, 1 €, 2 € et 5 € ;
- 78 tests automatisés.

## Fichiers ajoutés

- `tracker/signature.py`
- `tracker/methods.py`
- `tests_tracker/test_v38.py`
- `AUDIT_CONFORMITE_V38.md`
- `RAPPORT_TESTS_V38.md`
- `UTILISATION_V38.md`
- `LIVRAISON_V38.md`

## Fichiers principaux modifiés

- `tracker/experimental.py`
- `tracker/live.py`
- `tracker/measurements.py`
- `tracker/storage.py`
- `tracker/domain.py`
- `tracker/gui.py`
- `tests_tracker/test_extensions.py`
- `tests_tracker/test_measurements.py`
- `tests_tracker/test_tracker.py`
- `README.md`

Consultez `AUDIT_CONFORMITE_V38.md` avant d'interpréter une fonction comme
terminée. Les fonctions vidéo sans corpus annoté restent expérimentales.
