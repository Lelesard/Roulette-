# Repère fixe v26 — 6 novembre 2026

La vidéo de contrôle de la v25 a révélé une différence entre l'analyse hors ligne
et le Direct. L'observateur recalculait le cadre vert environ deux fois par
seconde. Ses variations de quelques pixels déplaçaient le contenu sous le centre
géométrique mémorisé et produisaient un faux mouvement angulaire.

La v26 fixe désormais le cadre accepté pendant toute la prise de vue. Une vraie
coupure caméra invalide toujours ce cadre et déclenche une nouvelle recherche.
Les points lumineux encore en phase d'initialisation, dont la confiance est
nulle, ne sont plus dessinés en jaune dans l'aperçu. Ils restent internes au
calcul jusqu'à obtenir une continuité suffisante.

La suite contient 48 tests réussis, dont un test qui impose plusieurs détections
de roue légèrement décalées et vérifie que les coordonnées utilisées pour le
suivi restent identiques. Le démarrage Qt hors écran est également validé.
