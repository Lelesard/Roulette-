# Historique rapide v31 — 6 novembre 2026

La carte jaune du résultat temporaire peut disparaître avant que deux lectures
OCR identiques aient été obtenues. Cette version analyse la région calibrée toutes
les 120 ms, au lieu de 350 ms, et enregistre dès la première lecture nette d'un
nombre compris entre 0 et 36.

Après l'ajout, le lecteur reste désarmé tant que la disparition de la carte n'a
pas été observée deux fois. Les nouvelles lectures de la même apparition sont
donc ignorées. Cette règle permet aussi d'accepter le même numéro sur deux tours
consécutifs, une fois la carte disparue entre les deux.

Le détecteur conserve le filtre de la carte de résultat : grand encadré jaune,
position et géométrie attendues dans la zone calibrée. Les petits montants des
jetons ne satisfont pas ces critères.

Les tests couvrent l'ajout sur une seule lecture, l'absence de doublon, le
réarmement après disparition et deux résultats consécutifs identiques.
